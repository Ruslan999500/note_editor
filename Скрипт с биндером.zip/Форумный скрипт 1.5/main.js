function initialize() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
}

async function initApp() {
  try {
    const module = await import(chrome.runtime.getURL('modules/adminMenu.js'));
    module.initExtension();
    
    const observer = new MutationObserver(() => {
      module.initExtension();
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: false,
      characterData: false
    });
    
  } catch (error) {
    console.error('Error initializing extension:', error);
  }
}

initialize();