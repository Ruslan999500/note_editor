export function getPlayerNickname() {
  const listItems = document.querySelectorAll('li[data-xf-list-type="ol"]');
  for (const item of listItems) {
    const text = item.textContent.trim();
    if (text.includes("Игровой ник нарушителя:")) {
      return text.replace("Игровой ник нарушителя:", "")
                .replace(/"/g, '')
                .trim();
    }
  }
  
  const possibleLabels = [
    "2. Игровой ник нарушителя",
    "2.Ник нарушителя",
    "Ник нарушителя:",
    "Ник нарушителя"
  ];
  
  for (const item of listItems) {
    const text = item.textContent.trim();
    for (const label of possibleLabels) {
      if (text.includes(label)) {
        const nickname = text.split(label)[1]?.trim();
        if (nickname) {
          return nickname.replace(/[":]/g, '').trim();
        }
      }
    }
  }
  
  return "Игрок";
}

export function getDayText(number) {
  number = parseInt(number);
  if (number === 1) return 'день';
  if (number >= 2 && number <= 4) return 'дня';
  return 'дней';
}

export function insertIntoFroalaEditor(text) {
  const editorElement = document.querySelector('.fr-element.fr-view');
  
  if (editorElement) {
    editorElement.innerHTML = '';
    const container = document.createElement('div');
    const lines = text.split('\n');
    let htmlContent = '';
    
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].trim() === '') continue;
      htmlContent += lines[i];
      if (i < lines.length - 1) htmlContent += '<br>';
    }
    
    container.innerHTML = `[CENTER][FONT=times new roman][B]${htmlContent}[/B][/FONT][/CENTER]`;
    editorElement.appendChild(container);
    
    const event = new Event('input', { bubbles: true });
    editorElement.dispatchEvent(event);
    editorElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } else {
    console.error('Не удалось найти редактор Froala');
    alert('Не удалось найти поле для ввода сообщения. Убедитесь, что редактор загружен.');
  }
}

export function createDraggable(element, header) {
  let isDragging = false;
  let offsetX, offsetY;
  
  header.addEventListener('mousedown', (e) => {
    isDragging = true;
    const rect = element.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    element.style.transform = 'none';
    document.body.style.cursor = 'move';
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', stopDrag);
    e.preventDefault();
  });
  
  function drag(e) {
    if (!isDragging) return;
    let newLeft = e.clientX - offsetX;
    let newTop = e.clientY - offsetY;
    const maxX = window.innerWidth - element.offsetWidth;
    const maxY = window.innerHeight - element.offsetHeight;
    newLeft = Math.max(0, Math.min(newLeft, maxX));
    newTop = Math.max(0, Math.min(newTop, maxY));
    element.style.left = newLeft + 'px';
    element.style.top = newTop + 'px';
  }
  
  function stopDrag() {
    isDragging = false;
    document.body.style.cursor = 'default';
    document.removeEventListener('mousemove', drag);
    document.removeEventListener('mouseup', stopDrag);
  }
}

export function removeElementById(id) {
  const element = document.getElementById(id);
  if (element) element.remove();
}

export function removeStylesById(id) {
  const styles = document.getElementById(id);
  if (styles) styles.remove();
}