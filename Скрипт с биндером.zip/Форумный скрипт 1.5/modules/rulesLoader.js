let adminRules = {};

export async function loadRules() {
  try {
    const response = await fetch(chrome.runtime.getURL('rules.json'));
    const rawRules = await response.json();
    
    const convertedRules = {};
    
    for (const [category, rules] of Object.entries(rawRules)) {
      convertedRules[category] = {};
      
      for (const [ruleNumber, ruleValue] of Object.entries(rules)) {
        if (typeof ruleValue === 'string') {
          convertedRules[category][ruleNumber] = {
            text: ruleValue,
            exceptions: null
          };
        } else {
          convertedRules[category][ruleNumber] = ruleValue;
        }
      }
    }
    
    console.log('[Admin Helper] Rules loaded successfully');
    return convertedRules;
  } catch (error) {
    console.error('[Admin Helper] Error loading rules:', error);
    return {
      "Основные положения": {
        "1.1": {
          text: "Нарушение правил дорожного движения: превышение скорости, проезд на красный свет, создание аварийных ситуаций.",
          exceptions: null
        }
      }
    };
  }
}

export function setAdminRules(rules) {
  adminRules = rules;
}

export function getAdminRules() {
  return adminRules;
}