let settingsMenuOpen = false;

export function showSettingsMenu() {
  if (settingsMenuOpen) {
    closeSettingsMenu();
    return;
  }
  
  removeExistingSettingsMenu();
  
  const menu = document.createElement('div');
  menu.id = 'adminHelperSettingsMenu';
  Object.assign(menu.style, {
    position: 'fixed',
    top: '55px',
    right: '15px',
    backgroundColor: '#2c2f33',
    border: '1px solid #1a1d21',
    borderRadius: '12px',
    padding: '15px',
    zIndex: '10000',
    color: 'white',
    boxShadow: '0 0 10px rgba(0,0,0,0.5)',
    width: '300px',
    cursor: 'default',
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  });
  
  menu.innerHTML = `
    <h3 style="margin: 0 0 10px 0; padding-bottom: 10px; border-bottom: 1px solid #4a5568;">Настройки расширения</h3>
    
    <button class="settingsMenuButton" data-section="themes">
      <div style="display: flex; align-items: center; gap: 10px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2"/>
          <path d="M12 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 16H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <span>Темы</span>
      </div>
    </button>
    
    <button class="settingsMenuButton" data-section="styles">
      <div style="display: flex; align-items: center; gap: 10px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 2H10V10H4V2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M4 14H10V22H4V14Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M14 14H20V22H14V14Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M14 2H20V10H14V2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Стили меню</span>
      </div>
    </button>
    
    <button class="settingsMenuButton" data-section="monitoring">
      <div style="display: flex; align-items: center; gap: 10px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M2 12H6L9 5L15 19L18 12H22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Мониторинг закрытых жалоб</span>
      </div>
    </button>
    
    <button class="settingsMenuButton" data-section="binder">
      <div style="display: flex; align-items: center; gap: 10px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 19.5V4.5C4 3.4 4.9 2.5 6 2.5H18C19.1 2.5 20 3.4 20 4.5V19.5C20 20.6 19.1 21.5 18 21.5H6C4.9 21.5 4 20.6 4 19.5Z" stroke="currentColor" stroke-width="2"/>
          <path d="M4 8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M16 5.5V2.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M8 5.5V2.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M4 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M4 16H9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M13 12H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <path d="M13 16H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <span>Управление биндами</span>
      </div>
    </button>
    
    <div id="settingsContent" style="margin-top: 10px; display: none; padding: 10px; background: #23272a; border-radius: 8px;">
      <div class="settingsContentSection" id="themesSection" style="display: none;">
        <h4>Настройки тем</h4>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="darkTheme">
            <span class="checkmark"></span>
          </label>
          <label for="darkTheme">Темная тема</label>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="compactMode">
            <span class="checkmark"></span>
          </label>
          <label for="compactMode">Компактный режим</label>
        </div>
      </div>
      
      <div class="settingsContentSection" id="stylesSection" style="display: none;">
        <h4>Стили меню</h4>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="roundedCorners">
            <span class="checkmark"></span>
          </label>
          <label for="roundedCorners">Закругленные углы</label>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="animations">
            <span class="checkmark"></span>
          </label>
          <label for="animations">Анимации элементов</label>
        </div>
      </div>
      
      <div class="settingsContentSection" id="monitoringSection" style="display: none;">
        <h4>Мониторинг жалоб</h4>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="autoRefresh">
            <span class="checkmark"></span>
          </label>
          <label for="autoRefresh">Автообновление каждые 5 минут</label>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="notifications">
            <span class="checkmark"></span>
          </label>
          <label for="notifications">Уведомления о новых жалобах</label>
        </div>
      </div>
      
      <div class="settingsContentSection" id="binderSection" style="display: none;">
        <h4>Управление биндами</h4>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="autoSaveBinds">
            <span class="checkmark"></span>
          </label>
          <label for="autoSaveBinds">Автосохранение биндов</label>
        </div>
        <button id="exportBindsBtn" class="settingsActionButton">Экспорт всех биндов</button>
        <button id="importBindsBtn" class="settingsActionButton">Импорт биндов</button>
        <button id="resetBindsBtn" class="settingsActionButton" style="background-color: #e74c3c;">Сбросить все бинды</button>
      </div>
    </div>
  `;

  document.body.appendChild(menu);
  settingsMenuOpen = true;
  
  const style = document.createElement('style');
  style.id = 'adminHelperSettingsMenuStyles';
  style.textContent = `
    .settingsMenuButton {
      background-color: #4a5568;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 10px;
      text-align: left;
      cursor: pointer;
      font-size: 14px;
      transition: all 0.2s ease;
      border: 1px solid #1a1d21;
    }
    .settingsMenuButton:hover {
      background-color: #2d3748;
    }
    .settingsMenuButton.active {
      background-color: #3a4350;
      border-color: #718096;
    }
    .checkbox-container {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px;
      margin: 5px 0;
      border-radius: 8px;
      background-color: #2d3748;
      border: 1px solid #1a1d21;
    }
    .round-checkbox {
      position: relative;
      width: 18px;
      height: 18px;
    }
    .round-checkbox input[type="checkbox"] {
      opacity: 0;
      position: absolute;
      width: 100%;
      height: 100%;
      cursor: pointer;
      z-index: 2;
    }
    .checkmark {
      position: absolute;
      top: 0;
      left: 0;
      width: 18px;
      height: 18px;
      background-color: #2d3748;
      border: 2px solid #1a1d21;
      border-radius: 50%;
      transition: all 0.2s ease;
    }
    .round-checkbox input[type="checkbox"]:checked ~ .checkmark {
      background-color: #4a5568;
      border-color: #1a1d21;
    }
    .checkmark:after {
      content: "";
      position: absolute;
      display: none;
      top: 50%;
      left: 50%;
      width: 8px;
      height: 8px;
      background: white;
      border-radius: 50%;
      transform: translate(-50%, -50%);
    }
    .round-checkbox input[type="checkbox"]:checked ~ .checkmark:after {
      display: block;
    }
    .settingsActionButton {
      width: 100%;
      padding: 10px;
      margin: 5px 0;
      background-color: #4a5568;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      transition: all 0.2s ease;
      border: 1px solid #1a1d21;
    }
    .settingsActionButton:hover {
      background-color: #2d3748;
    }
  `;
  document.head.appendChild(style);
  
  document.querySelectorAll('.settingsMenuButton').forEach(button => {
    button.addEventListener('click', function() {
      const section = this.dataset.section;
      document.querySelectorAll('.settingsMenuButton').forEach(btn => {
        btn.classList.toggle('active', btn === this);
      });
      
      document.querySelectorAll('.settingsContentSection').forEach(div => {
        div.style.display = 'none';
      });
      
      const contentSection = document.getElementById(`${section}Section`);
      const settingsContent = document.getElementById('settingsContent');
      
      if (contentSection) {
        contentSection.style.display = 'block';
        settingsContent.style.display = 'block';
      } else {
        settingsContent.style.display = 'none';
      }
    });
  });
  
  // Добавляем обработчики для новых кнопок
  document.getElementById('exportBindsBtn')?.addEventListener('click', exportBinds);
  document.getElementById('importBindsBtn')?.addEventListener('click', importBinds);
  document.getElementById('resetBindsBtn')?.addEventListener('click', resetBinds);
  
  document.addEventListener('click', handleOutsideClick);
  document.addEventListener('keydown', handleKeyDown);
}

function closeSettingsMenu() {
  settingsMenuOpen = false;
  removeExistingSettingsMenu();
  document.removeEventListener('click', handleOutsideClick);
  document.removeEventListener('keydown', handleKeyDown);
}

function removeExistingSettingsMenu() {
  const menu = document.getElementById('adminHelperSettingsMenu');
  if (menu) menu.remove();
  
  const styles = document.getElementById('adminHelperSettingsMenuStyles');
  if (styles) styles.remove();
}

function handleOutsideClick(e) {
  const settingsMenu = document.getElementById('adminHelperSettingsMenu');
  const settingsIcon = document.getElementById('adminHelperSettingsIcon');
  
  if (settingsMenu && !settingsMenu.contains(e.target) && e.target !== settingsIcon) {
    closeSettingsMenu();
  }
}

function handleKeyDown(e) {
  if (e.key === 'Escape') {
    closeSettingsMenu();
  }
}

// Новые функции для работы с биндами
async function exportBinds() {
    const binds = await new Promise(resolve => {
        chrome.storage.local.get(['binds'], result => resolve(result.binds || []));
    });
    
    const dataStr = JSON.stringify(binds, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `binds_${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
}

async function importBinds() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = async e => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = async event => {
            try {
                const importedBinds = JSON.parse(event.target.result);
                if (!Array.isArray(importedBinds)) {
                    throw new Error('Invalid file format');
                }
                
                // Сохраняем импортированные бинды
                await new Promise(resolve => {
                    chrome.storage.local.set({ binds: importedBinds }, resolve);
                });
                
                alert(`Успешно импортировано ${importedBinds.length} биндов!`);
                closeSettingsMenu();
            } catch (error) {
                console.error('Import error:', error);
                alert('Ошибка импорта: неверный формат файла');
            }
        };
        reader.readAsText(file);
    };
    
    input.click();
}

async function resetBinds() {
    if (confirm('Вы уверены, что хотите удалить ВСЕ сохраненные бинды? Это действие нельзя отменить.')) {
        await new Promise(resolve => {
            chrome.storage.local.set({ binds: [] }, resolve);
        });
        alert('Все бинды успешно удалены!');
        closeSettingsMenu();
    }
}