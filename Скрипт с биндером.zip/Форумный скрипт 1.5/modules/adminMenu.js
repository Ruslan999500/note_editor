export async function initExtension() {
  console.log('[Admin Helper] Extension started');
  
  try {
    const rulesLoader = await import(chrome.runtime.getURL('modules/rulesLoader.js'));
    const rules = await rulesLoader.loadRules();
    rulesLoader.setAdminRules(rules);
  } catch (error) {
    console.error('Error loading rules:', error);
  }
  
  const buttonGroup = document.querySelector('.formButtonGroup-primary');
  if (buttonGroup) {
    const replyBtn = buttonGroup.querySelector('button.button--primary.button--icon--reply');
    if (replyBtn && !document.getElementById('adminHelperBtn')) {
      // Кнопка Администрация
      const adminBtn = document.createElement('button');
      adminBtn.id = 'adminHelperBtn';
      adminBtn.className = 'button button--primary';
      adminBtn.style.marginLeft = '10px';
      adminBtn.style.borderRadius = '8px';
      adminBtn.style.boxShadow = '0 0 0 1px rgba(0,0,0,0.3)';
      adminBtn.textContent = 'Администрация';
      
      adminBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showAdminMenu();
      });

      buttonGroup.appendChild(adminBtn);
      
      // Кнопка Биндер
      const binderBtn = document.createElement('button');
      binderBtn.id = 'binderHelperBtn';
      binderBtn.className = 'button button--primary';
      binderBtn.style.marginLeft = '10px';
      binderBtn.style.borderRadius = '8px';
      binderBtn.style.boxShadow = '0 0 0 1px rgba(0,0,0,0.3)';
      binderBtn.textContent = 'Биндер';
      
      binderBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
          const binderModule = await import(chrome.runtime.getURL('modules/binderModule.js'));
          binderModule.showBinderMenu();
        } catch (error) {
          console.error('Error showing binder menu:', error);
          alert('Ошибка при открытии менеджера биндов');
        }
      });

      buttonGroup.appendChild(binderBtn);
    }
  }
  
  addSettingsIcon();
}

function addSettingsIcon() {
  if (document.getElementById('adminHelperSettingsIcon')) return;
  
  const navLinks = document.querySelector('.p-navgroup');
  if (!navLinks) return;
  
  const settingsLink = document.createElement('a');
  settingsLink.id = 'adminHelperSettingsIcon';
  settingsLink.href = '#';
  settingsLink.className = 'p-navgroup-link p-navgroup-link--icon p-navgroup-link--settings';
  settingsLink.setAttribute('aria-label', 'Настройки расширения');
  settingsLink.setAttribute('title', 'Настройки расширения');
  settingsLink.style.marginLeft = '5px';
  settingsLink.style.cursor = 'pointer';
  
  // Заменяем SVG на PNG изображение
  settingsLink.innerHTML = `
    <img src="${chrome.runtime.getURL('icons/settings-icon.png')}" width="20" height="20" alt="Настройки">
    <span class="p-navgroup-linkText" style="display: none;">Настройки</span>
  `;
  
  settingsLink.addEventListener('click', async function(e) {
    e.preventDefault();
    const settingsModule = await import(chrome.runtime.getURL('modules/settingsModule.js'));
    settingsModule.showSettingsMenu();
  });
  
  navLinks.appendChild(settingsLink);
}

export async function showAdminMenu() {
  console.log('[Admin Helper] Showing menu');
  
  await removeProofForm();
  await removePlayerComplaintForm();
  removeElementById('adminHelperMenu');
  removeStylesById('adminHelperMenuStyles');
  removeElementById('binderMenu'); // Добавлено удаление меню биндов
  removeStylesById('binderMenuStyles'); // Добавлено удаление стилей биндов

  const menu = document.createElement('div');
  menu.id = 'adminHelperMenu';
  Object.assign(menu.style, {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#2c2f33',
    border: '1px solid #1a1d21',
    borderRadius: '12px',
    padding: '20px',
    zIndex: '99999',
    color: 'white',
    boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 8 24px rgba(0,0,0,0.5)',
    width: '400px',
    cursor: 'default'
  });
  
  menu.innerHTML = `
    <div id="adminHelperMenuHeader" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; cursor: move; padding: 10px; margin: -20px -20px 15px -20px; background: #23272a; border-radius: 12px 12px 0 0; border-bottom: 1px solid #1a1d21;">
      <h3 style="margin: 0; padding-left: 10px;">Меню администрации</h3>
      <button id="closeAdminMenu" style="background: none; border: none; color: white; cursor: pointer; font-size: 1.5rem; padding: 0 15px;">&times;</button>
    </div>
    <div style="display: flex; flex-direction: column; gap: 10px;">
      <button id="adminComplaintsBtn" class="adminMenuButton">
        <div style="display: flex; align-items: center; gap: 10px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2"/>
            <path d="M12 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M12 16H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <span>Жалобы на администрацию</span>
        </div>
      </button>
      <button id="playerComplaintsBtn" class="adminMenuButton">
        <div style="display: flex; align-items: center; gap: 10px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 1.17157 16.1716C0.421427 16.9217 0 17.9391 0 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 11C11.2091 11 13 9.20914 13 7C13 4.79086 11.2091 3 9 3C6.79086 3 5 4.79086 5 7C5 9.20914 6.79086 11 9 11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M17 4C17.7956 4.30487 18.5587 4.71447 19.2688 5.21966C19.9789 5.72485 20.6295 6.3216 21.204 7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <span>Жалобы на игроков</span>
        </div>
      </button>
    </div>
  `;

  document.body.appendChild(menu);
  
  const style = document.createElement('style');
  style.id = 'adminHelperMenuStyles';
  style.textContent = `
    .adminMenuButton {
      background-color: #4a5568;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 12px 15px;
      text-align: left;
      cursor: pointer;
      font-size: 16px;
      transition: all 0.2s ease;
      position: relative;
      border: 1px solid #1a1d21;
      box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
    }
    .adminMenuButton:hover {
      background-color: #2d3748;
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.3);
    }
    .adminMenuButton:active {
      transform: translateY(1px);
      box-shadow: 0 2px 4px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.3);
    }
    .adminMenuButton svg {
      flex-shrink: 0;
    }
    #adminHelperMenuHeader {
      user-select: none;
    }
  `;
  document.head.appendChild(style);
  
  // Обработчик кликов вне меню
  const outsideClickListener = (e) => {
    if (!menu.contains(e.target) && e.target.id !== 'adminHelperBtn') {
      closeMenu();
    }
  };
  
  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      closeMenu();
    }
  };
  
  const closeMenu = () => {
    menu.remove();
    style.remove();
    document.removeEventListener('keydown', handleKeyDown);
    document.removeEventListener('click', outsideClickListener);
  };
  
  document.addEventListener('click', outsideClickListener);
  document.addEventListener('keydown', handleKeyDown);
  
  document.getElementById('closeAdminMenu').addEventListener('click', closeMenu);
  
  document.getElementById('adminComplaintsBtn').addEventListener('click', async () => {
    const { showProofForm } = await import(chrome.runtime.getURL('modules/proofForm.js'));
    showProofForm();
  });
  
  document.getElementById('playerComplaintsBtn').addEventListener('click', async () => {
    const { showPlayerComplaintForm } = await import(chrome.runtime.getURL('modules/playerComplaintForm.js'));
    showPlayerComplaintForm();
  });
  
  const header = document.getElementById('adminHelperMenuHeader');
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    utils.createDraggable(menu, header);
  } catch (error) {
    console.error('Error loading utils for draggable:', error);
  }
  
  menu.addEventListener('click', (e) => e.stopPropagation());
}

async function removeProofForm() {
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    utils.removeElementById('proofForm');
    utils.removeStylesById('proofFormStyles');
  } catch (error) {
    console.error('Error removing proof form:', error);
  }
}

async function removePlayerComplaintForm() {
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    utils.removeElementById('playerComplaintForm');
    utils.removeStylesById('playerComplaintFormStyles');
  } catch (error) {
    console.error('Error removing player complaint form:', error);
  }
}

function removeElementById(id) {
  const element = document.getElementById(id);
  if (element) element.remove();
}

function removeStylesById(id) {
  const styles = document.getElementById(id);
  if (styles) styles.remove();
}