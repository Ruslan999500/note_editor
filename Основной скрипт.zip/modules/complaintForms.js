export async function showPlayerComplaintForm() {
  try {
    // Загружаем необходимые модули
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    const rulesLoader = await import(chrome.runtime.getURL('modules/rulesLoader.js'));
    const adminRules = rulesLoader.getAdminRules();
    const playerNickname = utils.getPlayerNickname();

    // Удаляем другие элементы интерфейса
    utils.removeElementById('adminHelperMenu');
    utils.removeStylesById('adminHelperMenuStyles');
    utils.removeElementById('proofForm');
    utils.removeStylesById('proofFormStyles');
    utils.removeElementById('playerComplaintForm');
    utils.removeStylesById('playerComplaintFormStyles');

    const form = document.createElement('div');
    form.id = 'playerComplaintForm';
    Object.assign(form.style, {
      position: 'fixed',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      backgroundColor: '#2c2f33',
      border: '1px solid #1a1d21',
      borderRadius: '12px',
      padding: '20px',
      zIndex: '99999',
      color: 'white',
      boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 8px 24px rgba(0,0,0,0.5)',
      width: '500px',
      maxHeight: '90vh',
      overflowY: 'auto',
      cursor: 'default'
    });
    
    form.innerHTML = `
      <div id="playerComplaintHeader" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; cursor: move; padding: 10px; margin: -20px -20px 15px -20px; background: #23272a; border-radius: 12px 12px 0 0; border-bottom: 1px solid #1a1d21;">
        <h3 style="margin: 0; padding-left: 10px;">Жалоба на игрока</h3>
        <button id="closePlayerComplaintForm" style="background: none; border: none; color: white; cursor: pointer; font-size: 1.5rem; padding: 0 15px;">&times;</button>
      </div>
      <div style="display: flex; flex-direction: column; gap: 15px;">
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="requestRefutation">
            <span class="checkmark"></span>
          </label>
          <label for="requestRefutation">Запросить опровержение</label>
        </div>
        <div id="refutationForm" style="display: none; padding: 15px; background: #23272a; border-radius: 8px; border: 1px solid #1a1d21;">
          <div style="margin-bottom: 10px;">Доброго времени суток.</div>
          <div style="margin-bottom: 10px;">Запросил видеофиксацию от игрока.</div>
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
            <span>Ожидаем видеофиксацию в течении</span>
            <input type="number" id="hoursInput" min="1" max="72" value="24" style="width: 50px; padding: 5px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px;">
            <span>часов.</span>
          </div>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="playerWillBePunished">
            <span class="checkmark"></span>
          </label>
          <label for="playerWillBePunished">Игрок будет наказан</label>
        </div>
        <div id="punishmentForm" style="display: none; padding: 15px; background: #23272a; border-radius: 8px; width: 100%; box-sizing: border-box; border: 1px solid #1a1d21;">
          <div style="margin-bottom: 15px; width: 100%;">
            <div style="margin-bottom: 5px; text-align: left;">Игровой ник нарушителя:</div>
            <input type="text" id="playerNickname" value="${playerNickname}" style="width: 100%; padding: 8px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px; box-sizing: border-box;">
          </div>
          
          <div id="punishmentsContainer" style="margin-bottom: 15px;"></div>
          
          <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
            <button id="addPunishmentBtn" style="background: #4a5568; color: white; border: none; border-radius: 8px; padding: 8px 15px; cursor: pointer; border: 1px solid #1a1d21;">
              + Добавить наказание
            </button>
          </div>
          
          <div style="width: 100%;">
            <label for="punishmentComment">Комментарий:</label>
            <textarea id="punishmentComment" placeholder="Введите ваш комментарий..." style="width: 100%; margin-top: 5px; min-height: 60px; padding: 8px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px; box-sizing: border-box;"></textarea>
          </div>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="noViolations">
            <span class="checkmark"></span>
          </label>
          <label for="noViolations">Не увидел нарушений</label>
        </div>
        <div id="noViolationsCommentContainer" style="display: none; padding: 15px; background: #23272a; border-radius: 8px; border: 1px solid #1a1d21;">
          <label for="noViolationsComment">Комментарий:</label>
          <textarea id="noViolationsComment" placeholder="Введите ваш комментарий..." style="width: 100%; margin-top: 5px; min-height: 80px; padding: 8px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px; box-sizing: border-box;"></textarea>
        </div>
        <div style="display: flex; gap: 10px; margin-top: 15px; margin-bottom: 15px;">
          <button id="insertPlayerComplaintBtn" style="flex: 1; border-radius: 8px; border: 1px solid #1a1d21;">Вставить ответ</button>
          <button id="cancelPlayerComplaintBtn" style="flex: 1; background: #4a5568; border-radius: 8px; border: 1px solid #1a1d21;">Отмена</button>
        </div>
      </div>
    `;

    document.body.appendChild(form);
    
    const style = document.createElement('style');
    style.id = 'playerComplaintFormStyles';
    style.textContent = `
      .checkbox-container {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px;
        border-radius: 8px;
        background-color: #2d3748;
        border: 1px solid #1a1d21;
      }
      .round-checkbox {
        position: relative;
        width: 20px;
        height: 20px;
      }
      .round-checkbox input[type="checkbox"] {
        opacity: 0;
        position: absolute;
        width: 100%;
        height: 100%;
        cursor: pointer;
        z-index: 2;
      }
      .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        width: 20px;
        height: 20px;
        background-color: #2d3748;
        border: 2px solid #1a1d21;
        border-radius: 50%;
        transition: all 0.2s ease;
      }
      .round-checkbox input[type="checkbox"]:checked ~ .checkmark {
        background-color: #4a5568;
        border-color: #1a1d21;
      }
      .checkmark:after {
        content: "";
        position: absolute;
        display: none;
        top: 50%;
        left: 50%;
        width: 10px;
        height: 10px;
        background: white;
        border-radius: 50%;
        transform: translate(-50%, -50%);
      }
      .round-checkbox input[type="checkbox"]:checked ~ .checkmark:after {
        display: block;
      }
      #playerComplaintForm button {
        padding: 10px;
        border-radius: 8px;
        border: 1px solid #1a1d21;
        background-color: #4a5568;
        color: white;
        cursor: pointer;
        transition: background-color 0.2s;
      }
      #playerComplaintForm button:hover {
        background-color: #2d3748;
      }
      #playerComplaintHeader {
        user-select: none;
      }
      #refutationForm input[type="number"],
      #punishmentForm input[type="number"] {
        text-align: center;
      }
      #refutationForm input[type="number"]::-webkit-inner-spin-button,
      #refutationForm input[type="number"]::-webkit-outer-spin-button,
      #punishmentForm input[type="number"]::-webkit-inner-spin-button,
      #punishmentForm input[type="number"]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }
      #playerComplaintForm select,
      #playerComplaintForm textarea {
        width: 100%;
        padding: 8px;
        background: #2d3748;
        border: 1px solid #1a1d21;
        color: white;
        border-radius: 8px;
        box-sizing: border-box;
      }
      .rule-selector {
        position: relative;
      }
      .rule-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
        border: 1px solid #1a1d21;
        border-radius: 8px;
        cursor: pointer;
        background-color: #2d3748;
        box-sizing: border-box;
      }
      .rule-options {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background-color: #2d3748;
        border: 1px solid #1a1d21;
        border-radius: 8px;
        margin-top: 5px;
        max-height: 300px;
        overflow-y: auto;
        z-index: 10000;
        display: none;
        box-sizing: border-box;
      }
      .rule-option {
        padding: 8px;
        cursor: pointer;
        border-radius: 8px;
        margin-bottom: 5px;
        transition: background-color 0.2s;
        box-sizing: border-box;
        font-size: 14px;
        border: 1px solid rgba(0,0,0,0.1);
      }
      .rule-option:hover {
        background-color: #3a4350;
      }
      #punishmentForm {
        width: 100%;
        box-sizing: border-box;
      }
      #punishmentForm > div {
        margin-bottom: 15px;
        width: 100%;
      }
      #punishmentForm .rule-selector {
        width: 100%;
      }
      #punishmentForm textarea {
        width: 100%;
        box-sizing: border-box;
      }
      .rule-search-container {
        padding: 10px;
        border-bottom: 1px solid #1a1d21;
      }
      .punishmentRuleSearch {
        width: 100%;
        padding: 8px;
        border-radius: 8px;
        border: 1px solid #1a1d21;
        background-color: #2d3748;
        color: white;
        box-sizing: border-box;
      }
      .rule-category {
        margin-bottom: 5px;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid rgba(0,0,0,0.1);
      }
      .category-header {
        padding: 10px;
        background-color: #3a4350;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background-color 0.2s;
        font-size: 14px;
      }
      .category-header:hover {
        background-color: #4a5568;
      }
      .category-rules {
        background-color: #2a303c;
        padding: 5px 10px;
        display: none;
      }
      .rule-search-results {
        padding: 10px;
      }
      .no-results {
        padding: 20px;
        text-align: center;
        color: #a0aec0;
      }
      .punishment-block {
        background: #1e2227;
        border-radius: 8px;
        padding: 12px;
        margin-bottom: 12px;
        position: relative;
        border: 1px solid #1a1d21;
      }
      .removePunishmentBtn {
        background: #e74c3c !important;
        transition: background-color 0.2s;
        padding: 4px 8px !important;
        font-size: 14px;
      }
      .removePunishmentBtn:hover {
        background: #c0392b !important;
      }
      #punishmentsContainer {
        max-height: 250px;
        overflow-y: auto;
        padding-right: 5px;
        margin-bottom: 15px;
      }
      #punishmentsContainer::-webkit-scrollbar {
        width: 6px;
      }
      #punishmentsContainer::-webkit-scrollbar-track {
        background: #2d3748;
        border-radius: 8px;
      }
      #punishmentsContainer::-webkit-scrollbar-thumb {
        background: #4a5568;
        border-radius: 8px;
      }
      #punishmentsContainer::-webkit-scrollbar-thumb:hover {
        background: #718096;
      }
    `;
    document.head.appendChild(style);
    
    // Обработчики для чекбоксов
    const checkboxes = [
      document.getElementById('requestRefutation'),
      document.getElementById('playerWillBePunished'),
      document.getElementById('noViolations')
    ];
    
    checkboxes.forEach(checkbox => {
      checkbox.addEventListener('change', function() {
        if (this.checked) {
          checkboxes.forEach(cb => {
            if (cb !== this) cb.checked = false;
          });
          
          document.getElementById('refutationForm').style.display = 
            this.id === 'requestRefutation' ? 'block' : 'none';
          document.getElementById('punishmentForm').style.display = 
            this.id === 'playerWillBePunished' ? 'block' : 'none';
          document.getElementById('noViolationsCommentContainer').style.display = 
            this.id === 'noViolations' ? 'block' : 'none';
        } else {
          if (this.id === 'requestRefutation') {
            document.getElementById('refutationForm').style.display = 'none';
          } else if (this.id === 'playerWillBePunished') {
            document.getElementById('punishmentForm').style.display = 'none';
          } else if (this.id === 'noViolations') {
            document.getElementById('noViolationsCommentContainer').style.display = 'none';
          }
        }
      });
    });
    
    // Контейнер для наказаний
    const punishmentsContainer = document.getElementById('punishmentsContainer');
    
    // Функция для создания блока наказания
    function createPunishmentBlock() {
      const punishmentBlock = document.createElement('div');
      punishmentBlock.className = 'punishment-block';
      punishmentBlock.innerHTML = `
        <div style="margin-bottom: 10px; width: 100%;">
          <div style="margin-bottom: 5px; text-align: left;">Мера наказания:</div>
          <div style="display: flex; gap: 10px; align-items: center; justify-content: space-between; width: 100%;">
            <select class="punishmentType" style="padding: 8px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px; flex: 1; box-sizing: border-box;">
              <option value="minutes">Минуты</option>
              <option value="days">Дни</option>
              <option value="warns">Варны</option>
            </select>
            <input type="number" class="punishmentAmount" min="1" max="100" value="1" style="width: 60px; padding: 8px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px; text-align: center; box-sizing: border-box;">
            <span>-</span>
            <select class="punishmentAction" style="padding: 8px; background: #2d3748; border: 1px solid #1a1d21; color: white; border-radius: 8px; flex: 1; box-sizing: border-box;">
              <option value="мута">Мут</option>
              <option value="джайла">Джаил</option>
              <option value="варна">Варн</option>
              <option value="бана">Бан</option>
              <option value="ганбана">Ганбан</option>
              <option value="драйвбана">Драйвбан</option>
            </select>
          </div>
        </div>
        <div style="margin-bottom: 10px; width: 100%;">
          <div class="rule-selector" style="width: 100%;">
            <div class="rule-toggle punishmentRuleToggle" style="width: 100%;">
              <span>Выберите правило (не обязательно)</span>
              <span>▼</span>
            </div>
            <div class="rule-options punishmentRuleOptions" style="width: 100%;"></div>
          </div>
          <div class="selectedPunishmentRule" style="display: none; padding: 10px; background: #2d3748; border-radius: 8px; margin-top: 10px; width: 100%; box-sizing: border-box; border: 1px solid #1a1d21;"></div>
        </div>
        <div style="display: flex; justify-content: flex-end; margin-top: 10px;">
          <button class="removePunishmentBtn" style="background: #e74c3c; color: white; border: none; border-radius: 8px; padding: 5px 10px; cursor: pointer; border: 1px solid #1a1d21;">Удалить наказание</button>
        </div>
      `;
      
      return punishmentBlock;
    }

    // Функция для добавления нового наказания
    function addPunishmentBlock() {
      const punishmentBlock = createPunishmentBlock();
      punishmentsContainer.appendChild(punishmentBlock);
      punishmentsContainer.scrollTop = punishmentsContainer.scrollHeight;
      
      const punishmentRuleOptions = punishmentBlock.querySelector('.punishmentRuleOptions');
      
      // Контейнер для поиска
      const searchContainer = document.createElement('div');
      searchContainer.className = 'rule-search-container';
      searchContainer.innerHTML = '<input type="text" class="punishmentRuleSearch" placeholder="Поиск по правилам...">';
      punishmentRuleOptions.appendChild(searchContainer);
      
      // Контейнер для категорий
      const categoriesContainer = document.createElement('div');
      categoriesContainer.className = 'punishmentRuleCategories';
      punishmentRuleOptions.appendChild(categoriesContainer);
      
      // Контейнер для результатов поиска
      const searchResultsContainer = document.createElement('div');
      searchResultsContainer.className = 'punishmentRuleSearchResults rule-search-results';
      punishmentRuleOptions.appendChild(searchResultsContainer);
      
      // Обработчик кликов по правилам
      punishmentRuleOptions.addEventListener('click', function(e) {
        const ruleOption = e.target.closest('.rule-option');
        if (ruleOption) {
          const ruleNumber = ruleOption.dataset.ruleNumber;
          const ruleText = ruleOption.dataset.ruleText;
          const selectedRule = punishmentBlock.querySelector('.selectedPunishmentRule');
          
          selectedRule.innerHTML = `
            <strong>Выбранное правило ${ruleNumber}:</strong><br>
            [QUOTE="${ruleNumber}"]${ruleText}[/QUOTE]
          `;
          selectedRule.style.display = 'block';
          selectedRule.dataset.ruleNumber = ruleNumber;
          selectedRule.dataset.ruleText = ruleText;
          punishmentRuleOptions.style.display = 'none';
        }
      });

      // Функция отображения категорий
      function renderPunishmentCategories() {
        categoriesContainer.innerHTML = '';
        searchResultsContainer.style.display = 'none';
        categoriesContainer.style.display = 'block';
        
        for (const [categoryName, rules] of Object.entries(adminRules)) {
          const categoryElement = document.createElement('div');
          categoryElement.className = 'rule-category';
          categoryElement.innerHTML = `
            <div class="category-header">
              <span>${categoryName}</span>
              <span class="category-arrow">▶</span>
            </div>
            <div class="category-rules"></div>
          `;
          
          const header = categoryElement.querySelector('.category-header');
          const rulesContainer = categoryElement.querySelector('.category-rules');
          
          header.addEventListener('click', () => {
            const isOpen = rulesContainer.style.display === 'block';
            rulesContainer.style.display = isOpen ? 'none' : 'block';
            header.querySelector('.category-arrow').textContent = isOpen ? '▶' : '▼';
          });
          
          for (const [ruleNumber, ruleData] of Object.entries(rules)) {
            const ruleElement = document.createElement('div');
            ruleElement.className = 'rule-option';
            ruleElement.dataset.ruleNumber = ruleNumber;
            
            let fullRuleText = ruleData.text;
            if (ruleData.exceptions) {
              fullRuleText += `\n${ruleData.exceptions}`;
            }
            ruleElement.dataset.ruleText = fullRuleText;
            
            let displayText = ruleData.text;
            if (ruleData.exceptions) {
              displayText += " [исключение]";
            }
            
            ruleElement.innerHTML = `<strong>${ruleNumber}:</strong> ${displayText.substring(0, 60)}${displayText.length > 60 ? '...' : ''}`;
            rulesContainer.appendChild(ruleElement);
          }
          
          categoriesContainer.appendChild(categoryElement);
        }
      }
      
      // Обработчик поиска
      punishmentBlock.querySelector('.punishmentRuleSearch').addEventListener('input', function() {
        const searchText = this.value.toLowerCase().trim();
        
        if (searchText === '') {
          renderPunishmentCategories();
          return;
        }
        
        categoriesContainer.style.display = 'none';
        searchResultsContainer.style.display = 'block';
        searchResultsContainer.innerHTML = '';
        
        let foundResults = false;
        
        for (const [categoryName, rules] of Object.entries(adminRules)) {
          for (const [ruleNumber, ruleData] of Object.entries(rules)) {
            const searchContent = `${ruleNumber} ${ruleData.text} ${ruleData.exceptions || ''} ${categoryName}`.toLowerCase();
            
            if (searchContent.includes(searchText)) {
              foundResults = true;
              const ruleElement = document.createElement('div');
              ruleElement.className = 'rule-option';
              ruleElement.dataset.ruleNumber = ruleNumber;
              
              let fullRuleText = ruleData.text;
              if (ruleData.exceptions) {
                fullRuleText += `\n${ruleData.exceptions}`;
              }
              ruleElement.dataset.ruleText = fullRuleText;
              
              let displayText = ruleData.text;
              if (ruleData.exceptions) {
                displayText += ` [исключение]`;
              }
              
              ruleElement.innerHTML = `
                <div><strong>${ruleNumber}</strong> (${categoryName})</div>
                <div>${displayText.substring(0, 80)}${displayText.length > 80 ? '...' : ''}</div>
              `;
              searchResultsContainer.appendChild(ruleElement);
            }
          }
        }
        
        if (!foundResults) {
          searchResultsContainer.innerHTML = '<div class="no-results">Ничего не найдено</div>';
        }
      });
      
      // Инициализация категорий
      renderPunishmentCategories();
      
      // Обработчик открытия/закрытия списка правил
      punishmentBlock.querySelector('.punishmentRuleToggle').addEventListener('click', () => {
        if (punishmentRuleOptions.style.display === 'block') {
          punishmentRuleOptions.style.display = 'none';
        } else {
          punishmentRuleOptions.style.display = 'block';
          punishmentBlock.querySelector('.punishmentRuleSearch').value = '';
          renderPunishmentCategories();
        }
      });
      
      // Обработчик кнопки удаления наказания
      punishmentBlock.querySelector('.removePunishmentBtn').addEventListener('click', function() {
        if (punishmentsContainer.children.length > 1) {
          punishmentBlock.remove();
        } else {
          alert('Должно остаться хотя бы одно наказание');
        }
      });
    }
    
    // Добавляем первое наказание
    addPunishmentBlock();
    
    // Обработчик кнопки добавления наказания
    document.getElementById('addPunishmentBtn').addEventListener('click', addPunishmentBlock);
    
    // Обработчики кнопок
    document.getElementById('closePlayerComplaintForm').addEventListener('click', async () => {
      utils.removeElementById('playerComplaintForm');
      utils.removeStylesById('playerComplaintFormStyles');
      const adminMenu = await import(chrome.runtime.getURL('modules/adminMenu.js'));
      adminMenu.showAdminMenu();
    });
    
    document.getElementById('cancelPlayerComplaintBtn').addEventListener('click', async () => {
      utils.removeElementById('playerComplaintForm');
      utils.removeStylesById('playerComplaintFormStyles');
      const adminMenu = await import(chrome.runtime.getURL('modules/adminMenu.js'));
      adminMenu.showAdminMenu();
    });
    
    document.getElementById('insertPlayerComplaintBtn').addEventListener('click', () => {
      const selectedOption = checkboxes.find(cb => cb.checked);
      if (!selectedOption) {
        alert('Пожалуйста, выберите один из вариантов');
        return;
      }
      
      let response = '';
      
      if (selectedOption.id === 'requestRefutation') {
        const hours = document.getElementById('hoursInput').value || '24';
        response = `Доброго времени суток.\nЗапросил видеофиксацию от игрока.\nОжидаем видеофиксацию в течении ${hours} часов.`;
      } 
      else if (selectedOption.id === 'playerWillBePunished') {
        const nickname = document.getElementById('playerNickname').value || playerNickname;
        const comment = document.getElementById('punishmentComment').value.trim();
        
        // Собираем все наказания
        const punishmentBlocks = document.querySelectorAll('.punishment-block');
        const punishments = [];
        
        punishmentBlocks.forEach(block => {
          const punishmentType = block.querySelector('.punishmentType').value;
          const punishmentAmount = block.querySelector('.punishmentAmount').value || '1';
          const punishmentAction = block.querySelector('.punishmentAction').value;
          const ruleNumber = block.querySelector('.selectedPunishmentRule')?.dataset.ruleNumber;
          const ruleText = block.querySelector('.selectedPunishmentRule')?.dataset.ruleText;
          
          let punishmentText = '';
          
          if (punishmentAction === 'варна') {
            if (punishmentAmount === '1') {
              punishmentText = '1-го варна';
            } else if (punishmentAmount === '2') {
              punishmentText = '2-х варнов';
            } else if (punishmentAmount === '3') {
              punishmentText = '3-х варнов';
            } else {
              punishmentText = `${punishmentAmount} варнов`;
            }
          }
          else if (punishmentAction === 'ганбана' || punishmentAction === 'драйвбана') {
            punishmentText = `${punishmentAmount} ${utils.getDayText(punishmentAmount)} ${punishmentAction}`;
          }
          else {
            if (punishmentType === 'minutes') {
              punishmentText = `${punishmentAmount} минут ${punishmentAction}`;
            } else if (punishmentType === 'days') {
              punishmentText = `${punishmentAmount} ${utils.getDayText(punishmentAmount)} ${punishmentAction}`;
            }
          }
          
          punishments.push({
            text: punishmentText,
            ruleNumber: ruleNumber,
            ruleText: ruleText
          });
        });
        
        if (punishments.length === 0) {
          alert('Пожалуйста, добавьте хотя бы одно наказание');
          return;
        }
        
        response = `Доброго времени суток уважаемый игрок.\nИгрок ${nickname} получит наказание в виде:\n`;
        
        punishments.forEach((punishment) => {
          if (punishment.ruleNumber) {
            response += `- ${punishment.text} по правилу ${punishment.ruleNumber}\n`;
          } else {
            response += `- ${punishment.text}\n`;
          }
        });
        
        const rulesToShow = punishments.filter(p => p.ruleNumber);
        if (rulesToShow.length > 0) {
          response += `\nПравила:\n`;
          rulesToShow.forEach((punishment) => {
            response += `[QUOTE="${punishment.ruleNumber}"]${punishment.ruleText}[/QUOTE]\n`;
          });
        }
        
        if (comment) {
          response += `\n${comment}`;
        }
        
        response += `\nЗакрыто.`;
      }
      else if (selectedOption.id === 'noViolations') {
        const comment = document.getElementById('noViolationsComment').value.trim();
        response = 'Доброго времени суток.\nНе увидел нарушений от игрока.';
        if (comment) {
          response += '\n' + comment;
        }
        response += '\nЗакрыто.';
      }
      
      utils.insertIntoFroalaEditor(response);
      utils.removeElementById('playerComplaintForm');
      utils.removeStylesById('playerComplaintFormStyles');
    });
    
    // Drag and drop для формы
    const header = document.getElementById('playerComplaintHeader');
    utils.createDraggable(form, header);
    
    form.addEventListener('click', (e) => e.stopPropagation());
    
    document.addEventListener('click', (e) => {
      if (!form.contains(e.target) && e.target.id !== 'adminHelperBtn') {
        utils.removeElementById('playerComplaintForm');
        utils.removeStylesById('playerComplaintFormStyles');
      }
    });
  } catch (error) {
    console.error('Error showing player complaint form:', error);
  }
}