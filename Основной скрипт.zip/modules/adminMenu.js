export async function initExtension() {
  console.log('[Admin Helper] Extension started');
  
  try {
    const rulesLoader = await import(chrome.runtime.getURL('modules/rulesLoader.js'));
    const rules = await rulesLoader.loadRules();
    rulesLoader.setAdminRules(rules);
  } catch (error) {
    console.error('Error loading rules:', error);
  }
  
  const buttonGroup = document.querySelector('.formButtonGroup-primary');
  if (buttonGroup) {
    const replyBtn = buttonGroup.querySelector('button.button--primary.button--icon--reply');
    if (replyBtn && !document.getElementById('adminHelperBtn')) {
      const adminBtn = document.createElement('button');
      adminBtn.id = 'adminHelperBtn';
      adminBtn.className = 'button button--primary';
      adminBtn.style.marginLeft = '10px';
      adminBtn.style.borderRadius = '8px';
      adminBtn.style.boxShadow = '0 0 0 1px rgba(0,0,0,0.3)';
      adminBtn.textContent = 'Администрация';
      
      adminBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showAdminMenu();
      });

      buttonGroup.appendChild(adminBtn);
      
      // Кнопка Биндер
      const binderBtn = document.createElement('button');
      binderBtn.id = 'binderHelperBtn';
      binderBtn.className = 'button button--primary';
      binderBtn.style.marginLeft = '10px';
      binderBtn.style.borderRadius = '8px';
      binderBtn.style.boxShadow = '0 0 0 1px rgba(0,0,0,0.3)';
      binderBtn.textContent = 'Биндер';
      
      binderBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
          const binderModule = await import(chrome.runtime.getURL('modules/binderModule.js'));
          binderModule.showBinderMenu();
        } catch (error) {
          console.error('Error showing binder menu:', error);
          alert('Ошибка при открытии менеджера биндов');
        }
      });

      buttonGroup.appendChild(binderBtn);
    }
  }
  
  addSettingsIcon();
  
  // Применяем только цвет меню вместо всех настроек темы
  applyMenuColor();
  
  // Добавляем глобальные стили для оформления форума
  updateGlobalStyles();
}

// ОБНОВЛЕННАЯ ФУНКЦИЯ ДЛЯ ПРИМЕНЕНИЯ ЦВЕТА МЕНЮ
async function applyMenuColor() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['themeSettings'], async (result) => {
      const themeSettings = result.themeSettings || {};
      const root = document.documentElement;
      
      // Применяем пользовательский цвет если есть
      if (themeSettings.isCustomColor && themeSettings.customHue) {
        root.dataset.customColor = 'true';
        try {
          const utils = await import(chrome.runtime.getURL('modules/utils.js'));
          utils.applyCustomColorScheme(themeSettings.customHue);
        } catch (error) {
          console.error('Error applying custom color scheme:', error);
        }
      } 
      // Иначе применяем стандартную схему
      else {
        const color = themeSettings.menuColor || 'gray';
        root.dataset.menuColor = color;
      }
      
      // Применяем CSS переменные
      applyGlobalVariables();
      resolve();
    });
  });
}

// ОБНОВЛЕННАЯ ФУНКЦИЯ ДЛЯ ОБНОВЛЕНИЯ ГЛОБАЛЬНЫХ СТИЛЕЙ
function updateGlobalStyles() {
  let globalStyles = document.getElementById('adminHelperGlobalStyles');
  
  if (!globalStyles) {
    globalStyles = document.createElement('style');
    globalStyles.id = 'adminHelperGlobalStyles';
    document.head.appendChild(globalStyles);
  }
  
  chrome.storage.local.get(['themeSettings'], (result) => {
    const themeSettings = result.themeSettings || {};
    const opacity = themeSettings.forumOpacity !== undefined ? themeSettings.forumOpacity : 1;
    
    globalStyles.textContent = `
      /* Стили для форума */
      .p-body {
        opacity: ${opacity} !important;
        font-family: var(--forum-font-family, Arial, sans-serif) !important;
        position: relative;
        z-index: 1;
      }
      
      /* Фон форума */
      .p-body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--forum-background, none);
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        z-index: -1;
        opacity: 0.1;
      }
      
      /* Для анимированных фонов */
      .p-body::before.video-bg {
        background: none !important;
      }
    `;
  });
}

function addSettingsIcon() {
  if (document.getElementById('adminHelperSettingsIcon')) return;
  
  const navLinks = document.querySelector('.p-navgroup');
  if (!navLinks) return;
  
  const settingsLink = document.createElement('a');
  settingsLink.id = 'adminHelperSettingsIcon';
  settingsLink.href = '#';
  settingsLink.className = 'p-navgroup-link p-navgroup-link--icon p-navgroup-link--settings';
  settingsLink.setAttribute('aria-label', 'Настройки расширения');
  settingsLink.setAttribute('title', 'Настройки расширения');
  settingsLink.style.marginLeft = '5px';
  settingsLink.style.cursor = 'pointer';
  
  // Заменяем SVG на PNG изображение
  settingsLink.innerHTML = `
    <img src="${chrome.runtime.getURL('icons/settings-icon.png')}" width="20" height="20" alt="Настройки">
    <span class="p-navgroup-linkText" style="display: none;">Настройки</span>
  `;
  
  settingsLink.addEventListener('click', async function(e) {
    e.preventDefault();
    const settingsModule = await import(chrome.runtime.getURL('modules/settingsModule.js'));
    settingsModule.showSettingsMenu();
  });
  
  navLinks.appendChild(settingsLink);
}

// Добавим функцию создания видео-фона
function createVideoBackground(src) {
  // Удаляем предыдущее видео, если есть
  const existingVideo = document.getElementById('adminHelperVideoBackground');
  if (existingVideo) {
    existingVideo.remove();
  }

  const video = document.createElement('video');
  video.id = 'adminHelperVideoBackground';
  video.autoplay = true;
  video.loop = true;
  video.muted = true;
  video.playsInline = true;
  video.src = src;
  video.style.position = 'fixed';
  video.style.top = '0';
  video.style.left = '0';
  video.style.width = '100%';
  video.style.height = '100%';
  video.style.objectFit = 'cover';
  video.style.zIndex = '-2';
  video.style.opacity = '0.1';

  document.body.appendChild(video);
}

// ОБНОВЛЕННАЯ ФУНКЦИЯ ГЛОБАЛЬНЫХ ПЕРЕМЕННЫХ
function applyGlobalVariables() {
  const root = document.documentElement;
  const color = root.dataset.menuColor || 'gray';
  
  // Если установлен пользовательский цвет - пропускаем стандартные схемы
  if (root.dataset.customColor === 'true') return;
  
  // Цветовые схемы
  const colorSchemes = {
    gray: {
      '--menu-bg': '#2c2f33',
      '--header-bg': '#23272a',
      '--menu-border': '#1a1d21',
      '--text-color': '#f0f0f0',
      '--section-bg': '#23272a',
      '--input-bg': '#2d3748',
      '--input-border': '#1a1d21',
      '--button-bg': '#4a5568',
      '--button-hover': '#3a4558',
      '--button-border': '#1a1d21',
      '--button-text': '#ffffff'
    },
    blue: {
      '--menu-bg': '#2c5282',
      '--header-bg': '#2b6cb0',
      '--menu-border': '#1a365d',
      '--text-color': '#e6f7ff',
      '--section-bg': '#3182ce',
      '--input-bg': '#4299e1',
      '--input-border': '#1a365d',
      '--button-bg': '#3182ce',
      '--button-hover': '#2172be',
      '--button-border': '#1a365d',
      '--button-text': '#ffffff'
    },
    green: {
      '--menu-bg': '#2f855a',
      '--header-bg': '#38a169',
      '--menu-border': '#1e4530',
      '--text-color': '#f0fff4',
      '--section-bg': '#38a169',
      '--input-bg': '#48bb78',
      '--input-border': '#1e4530',
      '--button-bg': '#38a169',
      '--button-hover': '#289159',
      '--button-border': '#1e4530',
      '--button-text': '#ffffff'
    },
    purple: {
      '--menu-bg': '#553c9a',
      '--header-bg': '#6b46c1',
      '--menu-border': '#322659',
      '--text-color': '#f5f0ff',
      '--section-bg': '#6b46c1',
      '--input-bg': '#805ad5',
      '--input-border': '#322659',
      '--button-bg': '#6b46c1',
      '--button-hover': '#5b36b1',
      '--button-border': '#322659',
      '--button-text': '#ffffff'
    },
    red: {
      '--menu-bg': '#c53030',
      '--header-bg': '#e53e3e',
      '--menu-border': '#742a2a',
      '--text-color': '#fff5f5',
      '--section-bg': '#e53e3e',
      '--input-bg': '#fc8181',
      '--input-border': '#742a2a',
      '--button-bg': '#e53e3e',
      '--button-hover': '#d52e2e',
      '--button-border': '#742a2a',
      '--button-text': '#ffffff'
    },
    turquoise: {
      '--menu-bg': '#AFEEEE',
      '--header-bg': '#7FFFD4',
      '--menu-border': '#40E0D0',
      '--text-color': '#000000',
      '--section-bg': '#7FFFD4',
      '--input-bg': '#AFEEEE',
      '--input-border': '#40E0D0',
      '--button-bg': '#48D1CC',
      '--button-hover': '#20B2AA',
      '--button-border': '#40E0D0',
      '--button-text': '#000000'
    }
  };

  // Применяем переменные цветовой схемы
  if (colorSchemes[color]) {
    Object.entries(colorSchemes[color]).forEach(([varName, value]) => {
      root.style.setProperty(varName, value);
    });
  }
  
  // Новые переменные для оформления форума
  root.style.setProperty('--forum-opacity', '1');
  root.style.setProperty('--forum-font-family', 'Arial, sans-serif');
  root.style.setProperty('--forum-background', 'none');
}

export async function showAdminMenu() {
  console.log('[Admin Helper] Showing menu');
  
  // Удаление меню биндов при открытии
  removeElementById('binderMenu');
  removeStylesById('binderMenuStyles');
  
  // Импорт модуля анимаций
  const anim = await import(chrome.runtime.getURL('modules/animations.js'));
  
  await removeProofForm();
  await removePlayerComplaintForm();
  removeElementById('adminHelperMenu');
  removeStylesById('adminHelperMenuStyles');

  const menu = document.createElement('div');
  menu.id = 'adminHelperMenu';
  Object.assign(menu.style, {
    position: 'fixed',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: 'var(--menu-bg)',
    border: '1px solid var(--menu-border)',
    borderRadius: '12px',
    padding: '20px',
    zIndex: '99999',
    color: 'var(--text-color)',
    boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 8 24px rgba(0,0,0,0.5)',
    width: '400px',
    cursor: 'default'
  });
  
  menu.innerHTML = `
    <div id="adminHelperMenuHeader" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; cursor: move; padding: 10px; margin: -20px -20px 15px -20px; background: var(--header-bg); border-radius: 12px 12px 0 0; border-bottom: 1px solid var(--menu-border);">
      <h3 style="margin: 0; padding-left: 10px;">Меню администрации</h3>
      <button id="closeAdminMenu" style="background: none; border: none; color: var(--text-color); cursor: pointer; font-size: 1.5rem; padding: 0 15px;">&times;</button>
    </div>
    <div style="display: flex; flex-direction: column; gap: 10px;">
      <button id="adminComplaintsBtn" class="adminMenuButton">
        <div style="display: flex; align-items: center; gap: 10px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2"/>
            <path d="M12 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M12 16H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <span>Жалобы на администрацию</span>
        </div>
      </button>
      <button id="playerComplaintsBtn" class="adminMenuButton">
        <div style="display: flex; align-items: center; gap: 10px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M17 21V19C17 17.9391 16.5786 16.9217 15.8284 16.1716C15.0783 15.4214 14.0609 15 13 15H5C3.93913 15 2.92172 15.4214 2.17157 16.1716C1.42143 16.9217 1 17.9391 1 19V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 11C11.2091 11 13 9.20914 13 7C13 4.79086 11.2091 3 9 3C6.79086 3 5 4.79086 5 7C5 9.20914 6.79086 11 9 11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M23 21V19C22.9993 18.1137 22.7044 17.2528 22.1614 16.5523C21.6184 15.8519 20.8581 15.3516 20 15.13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M17 4C17.7956 4.30487 18.5587 4.71447 19.2688 5.21966C19.9789 5.72485 20.6295 6.3216 21.204 7" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <span>Жалобы на игроков</span>
        </div>
      </button>
    </div>
  `;

  document.body.appendChild(menu);
  anim.fadeIn(menu);
  
  const style = document.createElement('style');
  style.id = 'adminHelperMenuStyles';
  style.textContent = `
    .adminMenuButton {
      background-color: var(--button-bg);
      color: var(--button-text);
      border: none;
      border-radius: 8px;
      padding: 12px 15px;
      text-align: left;
      cursor: pointer;
      font-size: 16px;
      transition: all 0.2s ease;
      position: relative;
      border: 1px solid var(--button-border);
      box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
    }
    .adminMenuButton:hover {
      background-color: var(--button-hover);
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.3);
    }
    .adminMenuButton:active {
      transform: translateY(1px);
      box-shadow: 0 2px 4px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.3);
    }
    .adminMenuButton svg {
      flex-shrink: 0;
    }
    #adminHelperMenuHeader {
      user-select: none;
    }
  `;
  document.head.appendChild(style);
  
  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      closeMenu();
    }
  };
  
  document.addEventListener('keydown', handleKeyDown);
  
  const closeMenu = () => {
        anim.fadeOut(menu, 300, () => {
            menu.remove();
            style.remove();
            document.removeEventListener('keydown', handleKeyDown);
        });
    };
  
  document.getElementById('closeAdminMenu').addEventListener('click', closeMenu);
  
  document.getElementById('adminComplaintsBtn').addEventListener('click', async () => {
    const { showProofForm } = await import(chrome.runtime.getURL('modules/proofForm.js'));
    showProofForm();
  });
  
  document.getElementById('playerComplaintsBtn').addEventListener('click', async () => {
    const { showPlayerComplaintForm } = await import(chrome.runtime.getURL('modules/playerComplaintForm.js'));
    showPlayerComplaintForm();
  });
  
  const header = document.getElementById('adminHelperMenuHeader');
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    utils.createDraggable(menu, header);
  } catch (error) {
    console.error('Error loading utils for draggable:', error);
  }
  
  menu.addEventListener('click', (e) => e.stopPropagation());
  
  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && e.target.id !== 'adminHelperBtn') {
      closeMenu();
    }
  });
}

async function removeProofForm() {
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    utils.removeElementById('proofForm');
    utils.removeStylesById('proofFormStyles');
  } catch (error) {
    console.error('Error removing proof form:', error);
  }
}

async function removePlayerComplaintForm() {
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    utils.removeElementById('playerComplaintForm');
    utils.removeStylesById('playerComplaintFormStyles');
  } catch (error) {
    console.error('Error removing player complaint form:', error);
  }
}

function removeElementById(id) {
  const element = document.getElementById(id);
  if (element) element.remove();
}

function removeStylesById(id) {
  const styles = document.getElementById(id);
  if (styles) styles.remove();
}

export function closeSettingsMenu() {
  const menu = document.getElementById('adminHelperSettingsMenu');
  if (menu) {
    menu.remove();
    const styles = document.getElementById('adminHelperSettingsMenuStyles');
    if (styles) styles.remove();
  }
}