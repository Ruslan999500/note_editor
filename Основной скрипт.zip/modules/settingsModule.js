// Модуль настроек
let settingsMenuOpen = false;
let currentHue = 0;
let isDragging = false;

// Цветовые схемы
const colorSchemes = {
  gray: {
    '--menu-bg': '#2c2f33',
    '--header-bg': '#23272a',
    '--menu-border': '#1a1d21',
    '--text-color': '#f0f0f0',
    '--section-bg': '#23272a',
    '--input-bg': '#2d3748',
    '--input-border': '#1a1d21',
    '--button-bg': '#4a5568',
    '--button-hover': '#3a4558',
    '--button-border': '#1a1d21',
    '--button-text': '#ffffff'
  },
  blue: {
    '--menu-bg': '#2c5282',
    '--header-bg': '#2b6cb0',
    '--menu-border': '#1a365d',
    '--text-color': '#e6f7ff',
    '--section-bg': '#3182ce',
    '--input-bg': '#4299e1',
    '--input-border': '#1a365d',
    '--button-bg': '#3182ce',
    '--button-hover': '#2172be',
    '--button-border': '#1a365d',
    '--button-text': '#ffffff'
  },
  green: {
    '--menu-bg': '#2f855a',
    '--header-bg': '#38a169',
    '--menu-border': '#1e4530',
    '--text-color': '#f0fff4',
    '--section-bg': '#38a169',
    '--input-bg': '#48bb78',
    '--input-border': '#1e4530',
    '--button-bg': '#38a169',
    '--button-hover': '#289159',
    '--button-border': '#1e4530',
    '--button-text': '#ffffff'
  },
  purple: {
    '--menu-bg': '#553c9a',
    '--header-bg': '#6b46c1',
    '--menu-border': '#322659',
    '--text-color': '#f5f0ff',
    '--section-bg': '#6b46c1',
    '--input-bg': '#805ad5',
    '--input-border': '#322659',
    '--button-bg': '#6b46c1',
    '--button-hover': '#5b36b1',
    '--button-border': '#322659',
    '--button-text': '#ffffff'
  },
  red: {
    '--menu-bg': '#c53030',
    '--header-bg': '#e53e3e',
    '--menu-border': '#742a2a',
    '--text-color': '#fff5f5',
    '--section-bg': '#e53e3e',
    '--input-bg': '#fc8181',
    '--input-border': '#742a2a',
    '--button-bg': '#e53e3e',
    '--button-hover': '#d52e2e',
    '--button-border': '#742a2a',
    '--button-text': '#ffffff'
  },
  turquoise: {
    '--menu-bg': '#AFEEEE',
    '--header-bg': '#7FFFD4',
    '--menu-border': '#40E0D0',
    '--text-color': '#000000',
    '--section-bg': '#7FFFD4',
    '--input-bg': '#AFEEEE',
    '--input-border': '#40E0D0',
    '--button-bg': '#48D1CC',
    '--button-hover': '#20B2AA',
    '--button-border': '#40E0D0',
    '--button-text': '#000000'
  }
};

// Тематические схемы
const themeSchemes = {
  dark: {
    '--global-bg': '#1a202c',
    '--global-text': '#e2e8f0',
    '--global-border': '#2d3748'
  },
  light: {
    '--global-bg': '#f7fafc',
    '--global-text': '#2d3748',
    '--global-border': '#cbd5e0'
  }
};

export function showSettingsMenu() {
  if (settingsMenuOpen) {
    closeSettingsMenu();
    return;
  }
  
  removeExistingSettingsMenu();
  
  const menu = document.createElement('div');
  menu.id = 'adminHelperSettingsMenu';
  Object.assign(menu.style, {
    position: 'fixed',
    top: '55px',
    right: '15px',
    backgroundColor: 'var(--menu-bg)',
    border: '1px solid var(--menu-border)',
    borderRadius: '12px',
    padding: '15px',
    zIndex: '10000',
    color: 'var(--text-color)',
    boxShadow: '0 0 10px rgba(0,0,0,0.5)',
    width: '350px',
    cursor: 'default',
    display: 'none',
    opacity: '0',
    flexDirection: 'column',
    gap: '8px'
  });
  
  menu.innerHTML = `
    <h3 style="margin: 0 0 10px 0; padding-bottom: 10px; border-bottom: 1px solid var(--menu-border);">Настройки расширения</h3>
    
    <div class="settings-buttons-grid">
      <button class="settingsMenuButton" data-section="styles">
        <div class="button-content">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 2H10V10H4V2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M4 14H10V22H4V14Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14 14H20V22H14V14Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14 2H20V10H14V2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Стили меню</span>
        </div>
      </button>
      
      <button class="settingsMenuButton" data-section="monitoring">
        <div class="button-content">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2 12H6L9 5L15 19L18 12H22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Мониторинг</span>
        </div>
      </button>
      
      <button class="settingsMenuButton" data-section="forum">
        <div class="button-content">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M21 11.5C21.0034 12.8199 20.6951 14.1219 20.1 15.3C19.3944 16.7118 18.3098 17.8992 16.9674 18.7293C15.6251 19.5594 14.0782 19.9994 12.5 20C11.1801 20.0034 9.87812 19.6951 8.7 19.1L3 21L4.9 15.3C4.30493 14.1219 3.99656 12.8199 4 11.5C4.00061 9.92179 4.44061 8.37488 5.27072 7.03258C6.10083 5.69028 7.28825 4.6056 8.7 3.9C9.87812 3.30493 11.1801 2.99656 12.5 3H13C15.0843 3.11499 17.053 3.99479 18.5291 5.47087C19.9948 6.94703 20.885 8.91569 21 11V11.5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>Форум</span>
        </div>
      </button>
      
      <!-- Кнопка управления биндами -->
      <button class="settingsMenuButton" data-section="binder">
        <div class="button-content">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 19.5V4.5C4 3.4 4.9 2.5 6 2.5H18C19.1 2.5 20 3.4 20 4.5V19.5C20 20.6 19.1 21.5 18 21.5H6C4.9 21.5 4 20.6 4 19.5Z" stroke="currentColor" stroke-width="2"/>
            <path d="M4 8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M16 5.5V2.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M8 5.5V2.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M4 12H9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M4 16H9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M13 12H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            <path d="M13 16H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          </svg>
          <span>Бинды</span>
        </div>
      </button>
    </div>
    
    <div id="settingsContent" style="margin-top: 10px; display: none; padding: 10px; background: var(--section-bg); border-radius: 8px;">
      <div class="settingsContentSection" id="stylesSection" style="display: none;">
        <h4 style="margin-top: 5px;">Настройки внешнего вида</h4>
        
        <h5 style="margin: 5px 0 5px 0;">Цветовая схема меню</h5>
        <div class="color-options">
          ${Object.entries(colorSchemes).map(([colorName, scheme]) => `
            <div class="color-option ${document.documentElement.dataset.menuColor === colorName ? 'active' : ''}" 
                 data-color="${colorName}" 
                 style="background: ${scheme['--menu-bg']}; border: 2px solid ${scheme['--menu-border']};">
              <div class="color-name">${getColorName(colorName)}</div>
            </div>
          `).join('')}
        </div>
        
        <h5 style="margin: 5px 0 5px 0;">Цветовая палитра</h5>
        <div class="color-palette-container">
          <div class="color-palette" id="colorPalette">
            <div class="palette-track"></div>
            <div class="palette-thumb"></div>
          </div>
          <div class="color-preview">
            <div class="preview-header"></div>
            <div class="preview-body"></div>
          </div>
          <button id="applyCustomColorBtn" class="apply-button">Применить</button>
        </div>
        
        <h5 style="margin: 5px 0 5px 0;">Тема оформления</h5>
        <div class="theme-options">
          <div class="theme-option ${document.documentElement.dataset.theme === 'dark' ? 'active' : ''}" data-theme="dark">
            <div class="theme-preview" style="background: linear-gradient(to right, #1a202c 50%, #2d3748 50%);"></div>
            <span>Темная</span>
          </div>
          <div class="theme-option ${document.documentElement.dataset.theme === 'light' ? 'active' : ''}" data-theme="light">
            <div class="theme-preview" style="background: linear-gradient(to right, #f7fafc 50%, #e2e8f0 50%);"></div>
            <span>Светлая</span>
          </div>
        </div>
      </div>
      
      <div class="settingsContentSection" id="monitoringSection" style="display: none;">
        <h4>Мониторинг жалоб</h4>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="autoRefresh" ${localStorage.getItem('autoRefresh') === 'true' ? 'checked' : ''}>
            <span class="checkmark"></span>
          </label>
          <label for="autoRefresh">Автообновление каждые 5 минут</label>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="notifications" ${localStorage.getItem('notifications') === 'true' ? 'checked' : ''}>
            <span class="checkmark"></span>
          </label>
          <label for="notifications">Уведомления о новых жалобах</label>
        </div>
      </div>
      
      <!-- Раздел для форума -->
      <div class="settingsContentSection" id="forumSection" style="display: none;">
        <h4>Настройки форума</h4>
        
        <div class="setting-row" style="display: flex; align-items: center; margin-bottom: 15px;">
          <label for="forumOpacity" style="margin-right: 10px; flex: 1;">Прозрачность форума:</label>
          <div style="flex: 3; display: flex; align-items: center;">
            <input type="range" id="forumOpacity" min="0.1" max="1" step="0.05" value="1" style="width: 100%;">
            <span id="forumOpacityValue" style="margin-left: 10px; min-width: 40px; text-align: right;">100%</span>
          </div>
        </div>
        
        <button id="applyForumSettings" class="apply-button">Применить настройки</button>
      </div>
      
      <!-- Раздел управления биндами -->
      <div class="settingsContentSection" id="binderSection" style="display: none;">
        <h4>Управление биндами</h4>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="autoSaveBinds" checked>
            <span class="checkmark"></span>
          </label>
          <label for="autoSaveBinds">Автосохранение биндов</label>
        </div>
        <button id="exportBindsBtn" class="settingsActionButton">Экспорт всех биндов</button>
        <button id="importBindsBtn" class="settingsActionButton">Импорт биндов</button>
        <button id="resetBindsBtn" class="settingsActionButton" style="background-color: #e74c3c;">Сбросить все бинды</button>
      </div>
    </div>
  `;

  document.body.appendChild(menu);
  settingsMenuOpen = true;
  
  const animPromise = import(chrome.runtime.getURL('modules/animations.js'));
  
  animPromise.then(anim => {
    anim.fadeIn(menu);
  });
  
  const style = document.createElement('style');
  style.id = 'adminHelperSettingsMenuStyles';
  style.textContent = `
    .settings-buttons-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
    }
    
    .settingsMenuButton {
      background-color: var(--button-bg);
      color: var(--button-text);
      border: none;
      border-radius: 8px;
      padding: 12px;
      text-align: center;
      cursor: pointer;
      font-size: 14px;
      transition: all 0.3s ease;
      border: 1px solid var(--button-border);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 80px;
    }
    
    .settingsMenuButton:hover {
      background-color: var(--button-hover);
      transform: translateY(-3px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    
    .settingsMenuButton.active {
      background-color: var(--button-hover);
      border-color: var(--menu-border);
      transform: translateY(-2px);
    }
    
    .button-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
    }
    
    .settingsMenuButton svg {
      width: 24px;
      height: 24px;
    }
    
    .settingsMenuButton span {
      font-size: 12px;
      text-align: center;
      line-height: 1.2;
    }
    
    .checkbox-container {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px;
      margin: 5px 0;
      border-radius: 8px;
      background-color: var(--section-bg);
      border: 1px solid var(--menu-border);
      transition: all 0.3s ease;
    }
    .round-checkbox {
      position: relative;
      width: 18px;
      height: 18px;
    }
    .round-checkbox input[type="checkbox"] {
      opacity: 0;
      position: absolute;
      width: 100%;
      height: 100%;
      cursor: pointer;
      z-index: 2;
    }
    .checkmark {
      position: absolute;
      top: 0;
      left: 0;
      width: 18px;
      height: 18px;
      background-color: var(--input-bg);
      border: 2px solid var(--input-border);
      border-radius: 50%;
      transition: all 0.3s ease;
    }
    .round-checkbox input[type="checkbox"]:checked ~ .checkmark {
      background-color: var(--button-bg);
      border-color: var(--button-border);
    }
    .checkmark:after {
      content: "";
      position: absolute;
      display: none;
      top: 50%;
      left: 50%;
      width: 8px;
      height: 8px;
      background: white;
      border-radius: 50%;
      transform: translate(-50%, -50%);
      transition: all 0.3s ease;
    }
    .round-checkbox input[type="checkbox"]:checked ~ .checkmark:after {
      display: block;
    }
    #settingsContent {
      transition: all 0.3s ease;
    }
    .settingsContentSection {
      transition: all 0.3s ease;
    }
    .color-options {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      margin-top: 10px;
    }
    .color-option {
      padding: 10px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    .color-option.active {
      box-shadow: 0 0 0 2px white;
    }
    .color-option:hover {
      transform: translateY(-3px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    .color-name {
      font-size: 12px;
      font-weight: bold;
      margin-top: 5px;
      color: var(--button-text);
      text-shadow: 0 1px 2px rgba(0,0,0,0.5);
    }
    .theme-options {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 10px;
      margin-top: 10px;
    }
    .theme-option {
      padding: 10px;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
      background-color: var(--section-bg);
      border: 1px solid var(--menu-border);
    }
    .theme-option.active {
      box-shadow: 0 0 0 2px var(--button-bg);
    }
    .theme-option:hover {
      transform: translateY(-3px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    .theme-preview {
      width: 100%;
      height: 40px;
      border-radius: 4px;
      margin-bottom: 5px;
    }
    .color-palette-container {
      display: flex;
      flex-direction: column;
      gap: 15px;
      margin-top: 10px;
      margin-bottom: 15px;
    }
    
    .apply-button {
      padding: 8px 15px;
      background-color: var(--button-bg);
      color: var(--button-text);
      border: 1px solid var(--button-border);
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      align-self: center;
    }
    
    .apply-button:hover {
      background-color: var(--button-hover);
      transform: translateY(-2px);
    }
    
    .color-palette {
      position: relative;
      height: 30px;
      border-radius: 15px;
      background: linear-gradient(to right, 
        #ff0000, #ff00ff, #0000ff, #00ffff, #00ff00, 
        #ffff00, #ff0000
      );
      overflow: hidden;
      cursor: pointer;
      box-shadow: 0 0 8px rgba(0,0,0,0.3);
      user-select: none;
    }
    
    .palette-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background: white;
      border: 3px solid #1a1d21;
      box-shadow: 0 0 8px rgba(0,0,0,0.6);
      z-index: 2;
      pointer-events: none;
      transition: left 0.1s ease;
    }
    .preview-header {
      background: var(--header-bg);
      height: 20px;
      border-radius: 4px 4px 0 0;
    }
    .preview-body {
      background: var(--menu-bg);
      height: 40px;
      border-radius: 0 0 4px 4px;
      margin-bottom: 10px;
    }
    
    /* Стили для кнопок управления биндами */
    .settingsActionButton {
      padding: 10px;
      background-color: var(--button-bg);
      color: var(--button-text);
      border: 1px solid var(--button-border);
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 10px;
      width: 100%;
      text-align: center;
      font-size: 14px;
    }
    
    .settingsActionButton:hover {
      background-color: var(--button-hover);
      transform: translateY(-2px);
    }
    
    #resetBindsBtn {
      background-color: #e74c3c;
      margin-top: 15px;
    }
    
    #resetBindsBtn:hover {
      background-color: #c0392b;
    }
  `;
  document.head.appendChild(style);
  
  // Загрузка сохраненных настроек
  loadSettings();
  
  document.querySelectorAll('.settingsMenuButton').forEach(button => {
    button.addEventListener('click', function() {
      const section = this.dataset.section;
      document.querySelectorAll('.settingsMenuButton').forEach(btn => {
        btn.classList.toggle('active', btn === this);
      });
      
      document.querySelectorAll('.settingsContentSection').forEach(div => {
        div.style.display = 'none';
      });
      
      const contentSection = document.getElementById(`${section}Section`);
      const settingsContent = document.getElementById('settingsContent');
      
      if (contentSection) {
        contentSection.style.display = 'block';
        settingsContent.style.display = 'block';
      } else {
        settingsContent.style.display = 'none';
      }
      
      // Инициализация палитры при открытии раздела стилей
      if (section === 'styles') {
        initColorPalette();
      }
    });
  });
  
  // Обработчики выбора темы
  document.querySelectorAll('.theme-option').forEach(option => {
    option.addEventListener('click', function() {
      const theme = this.dataset.theme;
      applyTheme(theme);
      saveSettings();
    });
  });
  
  // Обработчики выбора цвета
  document.querySelectorAll('.color-option').forEach(option => {
    option.addEventListener('click', function() {
      const color = this.dataset.color;
      applyColorScheme(color);
      saveSettings();
      updateColorPreview();
      
      // Сброс пользовательского цвета
      document.documentElement.dataset.customColor = 'false';
    });
  });
  
  // Обработчики чекбоксов
  document.getElementById('autoRefresh').addEventListener('change', function() {
    localStorage.setItem('autoRefresh', this.checked);
  });
  
  document.getElementById('notifications').addEventListener('change', function() {
    localStorage.setItem('notifications', this.checked);
  });
  
  // Обработчик для кнопки применения настроек форума
  document.getElementById('applyForumSettings')?.addEventListener('click', applyForumSettings);
  
  // Обработчики для кнопок управления биндами
  document.getElementById('exportBindsBtn')?.addEventListener('click', exportBinds);
  document.getElementById('importBindsBtn')?.addEventListener('click', importBinds);
  document.getElementById('resetBindsBtn')?.addEventListener('click', resetBinds);
  
  // Инициализация ползунка прозрачности
  initForumOpacitySlider();
  
  document.addEventListener('click', handleOutsideClick);
  document.addEventListener('keydown', handleKeyDown);
}

function getColorName(color) {
  const names = {
    gray: 'Серый',
    blue: 'Синий',
    green: 'Зеленый',
    purple: 'Фиолетовый',
    red: 'Красный',
    turquoise: 'Бирюзовый'
  };
  return names[color] || color;
}

function applyTheme(theme) {
  document.documentElement.removeAttribute('data-theme');
  document.documentElement.dataset.theme = theme;
  applyGlobalVariables();
}

function applyColorScheme(color) {
  document.documentElement.removeAttribute('data-menu-color');
  document.documentElement.dataset.menuColor = color;
  applyGlobalVariables();
  updateColorPreview();
}

function applyGlobalVariables() {
  const root = document.documentElement;
  const theme = root.dataset.theme || 'dark';
  const color = root.dataset.menuColor || 'gray';
  
  // Применяем глобальные переменные темы
  Object.entries(themeSchemes[theme]).forEach(([varName, value]) => {
    root.style.setProperty(varName, value);
  });
  
  // Применяем переменные цветовой схемы
  Object.entries(colorSchemes[color]).forEach(([varName, value]) => {
    root.style.setProperty(varName, value);
  });
  
  updateColorPreview();
}

function loadSettings() {
  chrome.storage.local.get(['themeSettings'], (result) => {
    const themeSettings = result.themeSettings || {};
    
    // Загружаем пользовательский цвет если есть
    if (themeSettings.isCustomColor && themeSettings.customHue) {
      document.documentElement.dataset.customColor = 'true';
      currentHue = themeSettings.customHue;
      applyCustomColorScheme(currentHue);
    } 
    // Иначе загружаем стандартную схему
    else {
      if (themeSettings.theme) {
        applyTheme(themeSettings.theme);
      }
      
      if (themeSettings.menuColor) {
        applyColorScheme(themeSettings.menuColor);
      }
    }
  });
}

function saveSettings() {
  const themeSettings = {
    theme: document.documentElement.dataset.theme || 'dark',
    menuColor: document.documentElement.dataset.menuColor || 'gray',
    // Сохраняем флаг и значение пользовательского цвета
    isCustomColor: document.documentElement.dataset.customColor === 'true',
    customHue: currentHue
  };
  
  chrome.storage.local.set({ themeSettings }, () => {
    console.log('Настройки темы сохранены');
  });
}

function closeSettingsMenu() {
  settingsMenuOpen = false;
  const animPromise = import(chrome.runtime.getURL('modules/animations.js'));
  const menu = document.getElementById('adminHelperSettingsMenu');
  
  if (menu) {
    animPromise.then(anim => {
      anim.fadeOut(menu, 300, () => {
        removeExistingSettingsMenu();
        document.removeEventListener('click', handleOutsideClick);
        document.removeEventListener('keydown', handleKeyDown);
      });
    });
  } else {
    removeExistingSettingsMenu();
  }
}

function removeExistingSettingsMenu() {
  const menu = document.getElementById('adminHelperSettingsMenu');
  if (menu) menu.remove();
  
  const styles = document.getElementById('adminHelperSettingsMenuStyles');
  if (styles) styles.remove();
}

function handleOutsideClick(e) {
  const settingsMenu = document.getElementById('adminHelperSettingsMenu');
  const settingsIcon = document.getElementById('adminHelperSettingsIcon');
  
  if (settingsMenu && !settingsMenu.contains(e.target) && e.target !== settingsIcon) {
    closeSettingsMenu();
  }
}

function handleKeyDown(e) {
  if (e.key === 'Escape') {
    closeSettingsMenu();
  }
}

// Инициализация цветовой палитры
function initColorPalette() {
  const palette = document.getElementById('colorPalette');
  if (!palette) return;

  const thumb = palette.querySelector('.palette-thumb');
  const applyBtn = document.getElementById('applyCustomColorBtn');

  // Установка начальной позиции
  currentHue = 0;
  setThumbPosition(currentHue);

  // Обработка перетаскивания на палитре
  palette.addEventListener('mousedown', (e) => {
    const rect = palette.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percent = Math.min(1, Math.max(0, x / rect.width));
    currentHue = Math.round(percent * 360);
    setThumbPosition(currentHue);
    updateCustomColorPreview(currentHue);

    isDragging = true;
    e.preventDefault();

    document.addEventListener('mousemove', handleDrag);
    document.addEventListener('mouseup', stopDrag);
  });

  function handleDrag(e) {
    if (!isDragging) return;
    e.preventDefault();

    const rect = palette.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percent = x / rect.width;
    currentHue = Math.round(percent * 360);
    setThumbPosition(currentHue);
    updateCustomColorPreview(currentHue);
  }

  function stopDrag() {
    isDragging = false;
    document.removeEventListener('mousemove', handleDrag);
    document.removeEventListener('mouseup', stopDrag);
  }

  // Обработчик кнопки применения
  applyBtn.addEventListener('click', () => {
    applyCustomColorScheme(currentHue);
    saveSettings();

    // Сброс предустановленных цветов
    document.querySelectorAll('.color-option').forEach(btn => {
      btn.classList.remove('active');
    });

    // Установка флага пользовательского цвета
    document.documentElement.dataset.customColor = 'true';
  });
}

function setThumbPosition(hue) {
  const palette = document.getElementById('colorPalette');
  if (!palette) return;
  
  const thumb = palette.querySelector('.palette-thumb');
  const percent = (hue / 360) * 100;
  thumb.style.left = `${percent}%`;
}

// Применение пользовательской цветовой схемы
function applyCustomColorScheme(hue) {
  const root = document.documentElement;
  currentHue = hue;
  
  // Генерация цветов на основе выбранного оттенка
  const menuBg = `hsl(${hue}, 70%, 20%)`;
  const headerBg = `hsl(${hue}, 70%, 15%)`;
  const menuBorder = `hsl(${hue}, 70%, 10%)`;
  const sectionBg = `hsl(${hue}, 70%, 18%)`;
  const inputBg = `hsl(${hue}, 70%, 25%)`;
  const buttonBg = `hsl(${hue}, 70%, 30%)`;
  const buttonHover = `hsl(${hue}, 70%, 25%)`;
  
  // Применение цветов
  root.style.setProperty('--menu-bg', menuBg);
  root.style.setProperty('--header-bg', headerBg);
  root.style.setProperty('--menu-border', menuBorder);
  root.style.setProperty('--section-bg', sectionBg);
  root.style.setProperty('--input-bg', inputBg);
  root.style.setProperty('--input-border', menuBorder);
  root.style.setProperty('--button-bg', buttonBg);
  root.style.setProperty('--button-hover', buttonHover);
  root.style.setProperty('--button-border', menuBorder);
  
  // Установка флага пользовательского цвета
  document.documentElement.dataset.customColor = 'true';
  updateColorPreview();
}

// Обновление предпросмотра для пользовательского цвета
function updateCustomColorPreview(hue) {
  const previewHeader = document.querySelector('.preview-header');
  const previewBody = document.querySelector('.preview-body');
  
  if (previewHeader && previewBody) {
    previewHeader.style.background = `hsl(${hue}, 70%, 15%)`;
    previewBody.style.background = `hsl(${hue}, 70%, 20%)`;
  }
}

// Обновление предпросмотра для текущей схемы
function updateColorPreview() {
  const previewHeader = document.querySelector('.preview-header');
  const previewBody = document.querySelector('.preview-body');
  
  if (previewHeader && previewBody) {
    previewHeader.style.background = 'var(--header-bg)';
    previewBody.style.background = 'var(--menu-bg)';
  }
}

// Инициализация ползунка прозрачности
function initForumOpacitySlider() {
  const opacitySlider = document.getElementById('forumOpacity');
  const opacityValue = document.getElementById('forumOpacityValue');
  
  if (!opacitySlider || !opacityValue) return;
  
  // Загрузка сохраненного значения
  chrome.storage.local.get(['themeSettings'], (result) => {
    const themeSettings = result.themeSettings || {};
    const savedOpacity = themeSettings.forumOpacity || 1;
    
    opacitySlider.value = savedOpacity;
    opacityValue.textContent = `${Math.round(savedOpacity * 100)}%`;
  });
  
  // Обработка изменений
  opacitySlider.addEventListener('input', () => {
    const value = parseFloat(opacitySlider.value);
    opacityValue.textContent = `${Math.round(value * 100)}%`;
  });
}

// Применение настроек форума
function applyForumSettings() {
  const opacitySlider = document.getElementById('forumOpacity');
  
  if (!opacitySlider) return;
  
  const opacityValue = parseFloat(opacitySlider.value);
  
  chrome.storage.local.get(['themeSettings'], (result) => {
    const themeSettings = result.themeSettings || {};
    themeSettings.forumOpacity = opacityValue;
    
    chrome.storage.local.set({ themeSettings }, () => {
      console.log('Настройки форума сохранены');
      
      // Обновляем стили
      const utilsModule = chrome.runtime.getURL('modules/utils.js');
      import(utilsModule).then(utils => {
        utils.updateGlobalStyles();
      });
      
      // Показываем уведомление
      const animModule = chrome.runtime.getURL('modules/animations.js');
      import(animModule).then(anim => {
        const notification = document.createElement('div');
        notification.textContent = 'Настройки форума применены!';
        notification.style.position = 'fixed';
        notification.style.bottom = '20px';
        notification.style.right = '20px';
        notification.style.backgroundColor = 'var(--button-bg)';
        notification.style.color = 'var(--button-text)';
        notification.style.padding = '10px 20px';
        notification.style.borderRadius = '8px';
        notification.style.zIndex = '10000';
        notification.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        
        document.body.appendChild(notification);
        anim.fadeIn(notification);
        
        setTimeout(() => {
          anim.fadeOut(notification, 500, () => {
            notification.remove();
          });
        }, 3000);
      });
    });
  });
}

// Функции для работы с биндами
async function exportBinds() {
    const binds = await new Promise(resolve => {
        chrome.storage.local.get(['binds'], result => resolve(result.binds || []));
    });
    
    const dataStr = JSON.stringify(binds, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `binds_${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
}

async function importBinds() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = async e => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = async event => {
            try {
                const importedBinds = JSON.parse(event.target.result);
                if (!Array.isArray(importedBinds)) {
                    throw new Error('Invalid file format');
                }
                
                // Сохраняем импортированные бинды
                await new Promise(resolve => {
                    chrome.storage.local.set({ binds: importedBinds }, resolve);
                });
                
                alert(`Успешно импортировано ${importedBinds.length} биндов!`);
                closeSettingsMenu();
            } catch (error) {
                console.error('Import error:', error);
                alert('Ошибка импорта: неверный формат файла');
            }
        };
        reader.readAsText(file);
    };
    
    input.click();
}

async function resetBinds() {
    if (confirm('Вы уверены, что хотите удалить ВСЕ сохраненные бинды? Это действие нельзя отменить.')) {
        await new Promise(resolve => {
            chrome.storage.local.set({ binds: [] }, resolve);
        });
        alert('Все бинды успешно удалены!');
        closeSettingsMenu();
    }
}