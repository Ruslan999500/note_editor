export function getPlayerNickname() {
  const listItems = document.querySelectorAll('li[data-xf-list-type="ol"]');
  for (const item of listItems) {
    const text = item.textContent.trim();
    if (text.includes("Игровой ник нарушителя:")) {
      return text.replace("Игровой ник нарушителя:", "")
                .replace(/"/g, '')
                .trim();
    }
  }
  
  const possibleLabels = [
    "2. Игровой ник нарушителя",
    "2.Ник нарушителя",
    "Ник нарушителя:",
    "Ник нарушителя"
  ];
  
  for (const item of listItems) {
    const text = item.textContent.trim();
    for (const label of possibleLabels) {
      if (text.includes(label)) {
        const nickname = text.split(label)[1]?.trim();
        if (nickname) {
          return nickname.replace(/[":]/g, '').trim();
        }
      }
    }
  }
  
  return "Игрок";
}

export function getDayText(number) {
  number = parseInt(number);
  if (number === 1) return 'день';
  if (number >= 2 && number <= 4) return 'дня';
  return 'дней';
}

export function insertIntoFroalaEditor(text) {
  const editorElement = document.querySelector('.fr-element.fr-view');
  
  if (editorElement) {
    // Очищаем редактор перед вставкой
    editorElement.innerHTML = '';
    
    // Создаем новый элемент для контента
    const container = document.createElement('div');
    container.innerHTML = text;
    
    // Вставляем контент в редактор
    editorElement.appendChild(container);
    
    // Триггерим событие обновления
    const event = new Event('input', { bubbles: true });
    editorElement.dispatchEvent(event);
    
    // Прокручиваем к редактору
    editorElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  } else {
    console.error('Не удалось найти редактор Froala');
    alert('Не удалось найти поле для ввода сообщения. Убедитесь, что редактор загружен.');
  }
}

export function createDraggable(element, header) {
  let isDragging = false;
  let offsetX, offsetY;
  
  header.addEventListener('mousedown', (e) => {
    isDragging = true;
    const rect = element.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    element.style.transform = 'none';
    document.body.style.cursor = 'move';
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', stopDrag);
    e.preventDefault();
  });
  
  function drag(e) {
    if (!isDragging) return;
    let newLeft = e.clientX - offsetX;
    let newTop = e.clientY - offsetY;
    const maxX = window.innerWidth - element.offsetWidth;
    const maxY = window.innerHeight - element.offsetHeight;
    newLeft = Math.max(0, Math.min(newLeft, maxX));
    newTop = Math.max(0, Math.min(newTop, maxY));
    element.style.left = newLeft + 'px';
    element.style.top = newTop + 'px';
  }
  
  function stopDrag() {
    isDragging = false;
    document.body.style.cursor = 'default';
    document.removeEventListener('mousemove', drag);
    document.removeEventListener('mouseup', stopDrag);
  }
}

export function removeElementById(id) {
  const element = document.getElementById(id);
  if (element) element.remove();
}

export function removeStylesById(id) {
  const styles = document.getElementById(id);
  if (styles) styles.remove();
}


export function removeExistingSettingsMenu() {
  const menu = document.getElementById('adminHelperSettingsMenu');
  if (menu) menu.remove();
  
  const styles = document.getElementById('adminHelperSettingsMenuStyles');
  if (styles) styles.remove();
}

export function closeSettingsMenu() {
  const menu = document.getElementById('adminHelperSettingsMenu');
  if (menu) {
    menu.remove();
    const styles = document.getElementById('adminHelperSettingsMenuStyles');
    if (styles) styles.remove();
  }
}
export function formatTextForInsertion(text) {
    // Заменяем переносы строк на BB-код [br][/br]
    let formattedText = text.replace(/\n/g, '[br][/br]');
    
    // Убираем дублирующиеся теги
    formattedText = formattedText.replace(/\[br\]\[\/br\]\[br\]\[\/br\]/g, '[br][/br]');
    
    // Добавляем переносы после QUOTE
    formattedText = formattedText.replace(
        /\[QUOTE="(\d+)"\](.*?)\[\/QUOTE\]/gs, 
        '[QUOTE="$1"]$2[/QUOTE][br][/br]'
    );
    
    return formattedText;
}

// НОВАЯ ФУНКЦИЯ: Обновление глобальных стилей
export function updateGlobalStyles() {
  let globalStyles = document.getElementById('adminHelperGlobalStyles');
  
  if (!globalStyles) {
    globalStyles = document.createElement('style');
    globalStyles.id = 'adminHelperGlobalStyles';
    document.head.appendChild(globalStyles);
  }
  
  chrome.storage.local.get(['themeSettings'], (result) => {
    const themeSettings = result.themeSettings || {};
    const opacity = themeSettings.forumOpacity !== undefined ? themeSettings.forumOpacity : 1;
    
    globalStyles.textContent = `
      /* Стили для форума */
      .p-body {
        opacity: ${opacity} !important;
        font-family: var(--forum-font-family, Arial, sans-serif) !important;
        position: relative;
        z-index: 1;
      }
      
      /* Фон форума */
      .p-body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--forum-background, none);
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        z-index: -1;
        opacity: 0.1;
      }
      
      /* Для анимированных фонов */
      .p-body::before.video-bg {
        background: none !important;
      }
    `;
  });
}

// Функция для преобразования HEX в HSL
export function hexToHsl(hex) {
  // Удаляем символ # если он есть
  hex = hex.replace(/^#/, '');
  
  // Преобразуем HEX в RGB
  let r, g, b;
  if (hex.length === 3) {
    r = parseInt(hex[0] + hex[0], 16);
    g = parseInt(hex[1] + hex[1], 16);
    b = parseInt(hex[2] + hex[2], 16);
  } else {
    r = parseInt(hex.slice(0, 2), 16);
    g = parseInt(hex.slice(2, 4), 16);
    b = parseInt(hex.slice(4, 6), 16);
  }
  
  // Нормализуем значения RGB
  r /= 255;
  g /= 255;
  b /= 255;
  
  // Находим минимум и максимум
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  
  // Вычисляем Lightness
  let h, s, l = (max + min) / 2;
  
  if (max === min) {
    h = s = 0; // achromatic
  } else {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    
    h /= 6;
  }
  
  // Возвращаем HSL в формате [h, s, l]
  return [
    Math.round(h * 360),
    Math.round(s * 100),
    Math.round(l * 100)
  ];
}

// НОВАЯ ФУНКЦИЯ: Конвертация HSL в RGB
export function hslToRgb(h, s, l) {
  h /= 360;
  s /= 100;
  l /= 100;
  
  let r, g, b;

  if (s === 0) {
    r = g = b = l;
  } else {
    const hue2rgb = (p, q, t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1/6) return p + (q - p) * 6 * t;
      if (t < 1/2) return q;
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
      return p;
    };

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    r = hue2rgb(p, q, h + 1/3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1/3);
  }

  return [
    Math.round(r * 255),
    Math.round(g * 255),
    Math.round(b * 255)
  ];
}

// Применение пользовательской цветовой схемы
export function applyCustomColorScheme(hue) {
  const root = document.documentElement;
  
  // Генерация цветов
  const menuBg = `hsl(${hue}, 70%, 20%)`;
  const headerBg = `hsl(${hue}, 70%, 15%)`;
  const menuBorder = `hsl(${hue}, 70%, 10%)`;
  const sectionBg = `hsl(${hue}, 70%, 18%)`;
  const inputBg = `hsl(${hue}, 70%, 25%)`;
  const buttonBg = `hsl(${hue}, 70%, 30%)`;
  const buttonHover = `hsl(${hue}, 70%, 25%)`;
  
  // Применение цветов
  root.style.setProperty('--menu-bg', menuBg);
  root.style.setProperty('--header-bg', headerBg);
  root.style.setProperty('--menu-border', menuBorder);
  root.style.setProperty('--section-bg', sectionBg);
  root.style.setProperty('--input-bg', inputBg);
  root.style.setProperty('--input-border', menuBorder);
  root.style.setProperty('--button-bg', buttonBg);
  root.style.setProperty('--button-hover', buttonHover);
  root.style.setProperty('--button-border', menuBorder);
  
  // Установка флага пользовательского цвета
  root.dataset.customColor = 'true';
}