export async function showProofForm() {
  try {
    const utils = await import(chrome.runtime.getURL('modules/utils.js'));
    const rulesLoader = await import(chrome.runtime.getURL('modules/rulesLoader.js'));
    const { fadeIn, fadeOut, slideDown, slideUp, scrollSmooth } = await import(chrome.runtime.getURL('modules/animations.js'));
    const adminRules = rulesLoader.getAdminRules();
    
    utils.removeElementById('adminHelperMenu');
    utils.removeStylesById('adminHelperMenuStyles');
    utils.removeElementById('playerComplaintForm');
    utils.removeStylesById('playerComplaintFormStyles');
    utils.removeElementById('proofForm');
    utils.removeStylesById('proofFormStyles');

    const proofForm = document.createElement('div');
    proofForm.id = 'proofForm';
    Object.assign(proofForm.style, {
      position: 'fixed',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      backgroundColor: 'var(--menu-bg)',
      border: '1px solid var(--menu-border)',
      borderRadius: '12px',
      padding: '20px',
      zIndex: '99999',
      color: 'var(--text-color)',
      boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 8px 24px rgba(0,0,0,0.5)',
      width: '500px',
      cursor: 'default',
      display: 'none',
      opacity: '0'
    });
    
    proofForm.innerHTML = `
      <div id="proofFormHeader" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; cursor: move; padding: 10px; margin: -20px -20px 15px -20px; background: var(--header-bg); border-radius: 12px 12px 0 0; border-bottom: 1px solid var(--menu-border);">
        <h3 style="margin: 0; padding-left: 10px;">Форма ответа на жалобу</h3>
        <button id="closeProofForm" style="background: none; border: none; color: var(--text-color); cursor: pointer; font-size: 1.5rem; padding: 0 15px;">&times;</button>
      </div>
      <div class="proof-form">
        <div>
          <label for="proofLink">Ссылка на видео или скриншот:</label>
          <input type="text" id="proofLink" placeholder="https://example.com/proof.mp4" style="width: 100%; margin-top: 5px; border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);">
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="needTimestamps">
            <span class="checkmark"></span>
          </label>
          <label for="needTimestamps">Добавить тайм-коды</label>
        </div>
        <div id="timestampsContainer" class="timestamps-container">
          <label>Тайм-коды:</label>
          <div id="timestampRows">
            <div class="timestamp-row">
              <div class="timestamp-time">
                <input type="text" class="timestamp-value" placeholder="Тайм-код (1:10 или 1:10-1:25)" style="border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);">
              </div>
              <div class="timestamp-separator">-</div>
              <div class="timestamp-desc">
                <input type="text" class="timestamp-description" placeholder="Описание нарушения" style="border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);">
              </div>
              <button class="remove-timestamp">×</button>
            </div>
          </div>
          <button id="addTimestampRow" class="add-timestamp-btn">Добавить тайм-код</button>
        </div>
        <div class="checkbox-container">
          <label class="round-checkbox">
            <input type="checkbox" id="needComment">
            <span class="checkmark"></span>
          </label>
          <label for="needComment">Добавить комментарий</label>
        </div>
        <div id="commentContainer" class="comment-container" style="display: none;">
          <label for="adminComment">Комментарий:</label>
          <textarea id="adminComment" placeholder="Введите ваш комментарий..." style="width: 100%; margin-top: 5px; min-height: 80px; border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);"></textarea>
        </div>
        <div class="rule-selector">
          <div class="rule-toggle" id="ruleToggle" style="border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg);">
            <span>Выберите правило (не обязательно)</span>
            <span>▼</span>
          </div>
          <div class="rule-options" id="ruleOptions"></div>
        </div>
        <div id="selectedRule" style="display: none; padding: 10px; background: var(--section-bg); border-radius: 8px; margin-top: 10px; border: 1px solid var(--menu-border);"></div>
        <div style="display: flex; gap: 10px; margin-top: 15px;">
          <button id="insertResponseBtn" style="flex: 1; border-radius: 8px; border: 1px solid var(--button-border); background: var(--button-bg); color: var(--button-text);">Вставить ответ</button>
          <button id="cancelProofForm" style="flex: 1; background: var(--button-bg); border-radius: 8px; border: 1px solid var(--button-border); color: var(--button-text);">Отмена</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(proofForm);
    fadeIn(proofForm);
    
    const proofFormStyles = document.createElement('style');
    proofFormStyles.id = 'proofFormStyles';
    proofFormStyles.textContent = `
      .proof-form {
        display: flex;
        flex-direction: column;
        gap: 15px;
        margin-top: 10px;
      }
      .proof-form input, .proof-form select, .proof-form textarea {
        padding: 10px;
        border-radius: 8px;
        border: 1px solid var(--input-border);
        background-color: var(--input-bg);
        color: var(--text-color);
        transition: all 0.3s ease;
      }
      .proof-form button {
        padding: 10px;
        border-radius: 8px;
        border: 1px solid var(--button-border);
        background-color: var(--button-bg);
        color: var(--button-text);
        cursor: pointer;
        transition: all 0.3s ease;
      }
      .proof-form button:hover {
        background-color: var(--button-hover);
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      }
      .rule-selector {
        position: relative;
      }
      .rule-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
        border: 1px solid var(--input-border);
        border-radius: 8px;
        cursor: pointer;
        background-color: var(--input-bg);
        transition: all 0.3s ease;
      }
      .rule-toggle:hover {
        transform: translateY(-2px);
      }
      .rule-options {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background-color: var(--input-bg);
        border: 1px solid var(--input-border);
        border-radius: 8px;
        margin-top: 5px;
        max-height: 400px;
        overflow-y: auto;
        z-index: 10000;
        display: none;
        transition: all 0.3s ease;
      }
      .rule-search-container {
        padding: 10px;
        border-bottom: 1px solid var(--input-border);
        transition: all 0.3s ease;
      }
      .rule-search-container input {
        width: 100%;
        padding: 8px;
        border-radius: 8px;
        border: 1px solid var(--input-border);
        background-color: var(--input-bg);
        color: var(--text-color);
        transition: all 0.3s ease;
      }
      .rule-category {
        margin-bottom: 5px;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid rgba(0,0,0,0.1);
        transition: all 0.3s ease;
      }
      .category-header {
        padding: 10px;
        background-color: var(--button-bg);
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: all 0.3s ease;
      }
      .category-header:hover {
        background-color: var(--button-hover);
        transform: translateX(3px);
      }
      .category-rules {
        background-color: var(--section-bg);
        padding: 5px 10px;
        display: none;
        transition: all 0.3s ease;
      }
      .rule-option {
        padding: 8px;
        cursor: pointer;
        border-radius: 8px;
        margin-bottom: 5px;
        transition: all 0.3s ease;
        border: 1px solid rgba(0,0,0,0.1);
        background-color: var(--section-bg);
      }
      .rule-option:hover {
        background-color: var(--button-hover);
        transform: translateX(5px);
      }
      .rule-search-results {
        display: none;
        padding: 10px;
        transition: all 0.3s ease;
      }
      .no-results {
        padding: 20px;
        text-align: center;
        color: #a0aec0;
        transition: all 0.3s ease;
      }
      .timestamps-container {
        display: none;
        margin-top: 10px;
      }
      .comment-container {
        display: none;
        margin-top: 10px;
      }
      .checkbox-container {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px;
        border-radius: 8px;
        background-color: var(--section-bg);
        border: 1px solid var(--menu-border);
        transition: all 0.3s ease;
      }
      .round-checkbox {
        position: relative;
        width: 20px;
        height: 20px;
      }
      .round-checkbox input[type="checkbox"] {
        opacity: 0;
        position: absolute;
        width: 100%;
        height: 100%;
        cursor: pointer;
        z-index: 2;
      }
      .checkmark {
        position: absolute;
        top: 0;
        left: 0;
        width: 20px;
        height: 20px;
        background-color: var(--input-bg);
        border: 2px solid var(--input-border);
        border-radius: 50%;
        transition: all 0.3s ease;
      }
      .round-checkbox input[type="checkbox"]:checked ~ .checkmark {
        background-color: var(--button-bg);
        border-color: var(--button-border);
      }
      .checkmark:after {
        content: "";
        position: absolute;
        display: none;
        top: 50%;
        left: 50%;
        width: 10px;
        height: 10px;
        background: white;
        border-radius: 50%;
        transform: translate(-50%, -50%);
        transition: all 0.3s ease;
      }
      .round-checkbox input[type="checkbox"]:checked ~ .checkmark:after {
        display: block;
      }
      .timestamp-row {
        display: flex;
        gap: 10px;
        margin-bottom: 10px;
        align-items: center;
        transition: all 0.3s ease;
      }
      .timestamp-time {
        flex: 1;
        position: relative;
      }
      .timestamp-time input {
        width: 100%;
        transition: all 0.3s ease;
      }
      .timestamp-desc {
        flex: 1;
      }
      .timestamp-desc input {
        width: 100%;
        transition: all 0.3s ease;
      }
      .timestamp-separator {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 30px;
        color: #a0aec0;
        font-weight: bold;
        transition: all 0.3s ease;
      }
      .remove-timestamp {
        background: none;
        border: none;
        color: #e74c3c;
        cursor: pointer;
        font-size: 1.2rem;
        line-height: 1;
        padding: 5px;
        margin-left: 5px;
        transition: all 0.3s ease;
      }
      .remove-timestamp:hover {
        transform: scale(1.2);
      }
      .add-timestamp-btn {
        width: 100%;
        padding: 10px;
        background-color: var(--button-bg);
        color: var(--button-text);
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-top: 5px;
        border: 1px solid var(--button-border);
      }
      .add-timestamp-btn:hover {
        background-color: var(--button-hover);
        transform: translateY(-2px);
      }
    `;
    document.head.appendChild(proofFormStyles);
    
    document.getElementById('needTimestamps').addEventListener('change', function() {
      if (this.checked) {
        slideDown(document.getElementById('timestampsContainer'), 300);
      } else {
        slideUp(document.getElementById('timestampsContainer'), 300);
      }
    });
    
    document.getElementById('needComment').addEventListener('change', function() {
      if (this.checked) {
        slideDown(document.getElementById('commentContainer'), 300);
      } else {
        slideUp(document.getElementById('commentContainer'), 300);
      }
    });
    
    function addTimestampRow() {
      const row = document.createElement('div');
      row.className = 'timestamp-row';
      row.innerHTML = `
        <div class="timestamp-time">
          <input type="text" class="timestamp-value" placeholder="Тайм-код (1:10 или 1:10-1:25)" style="border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);">
        </div>
        <div class="timestamp-separator">-</div>
        <div class="timestamp-desc">
          <input type="text" class="timestamp-description" placeholder="Описание нарушения" style="border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);">
        </div>
        <button class="remove-timestamp">×</button>
      `;
      row.querySelector('.remove-timestamp').addEventListener('click', () => {
        fadeOut(row, 300, () => row.remove());
      });
      document.getElementById('timestampRows').appendChild(row);
      scrollSmooth(row);
    }
    
    document.getElementById('addTimestampRow').addEventListener('click', addTimestampRow);
    document.querySelectorAll('.remove-timestamp').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const row = e.target.closest('.timestamp-row');
        fadeOut(row, 300, () => row.remove());
      });
    });
    
    const ruleOptions = document.getElementById('ruleOptions');
    
    const searchContainer = document.createElement('div');
    searchContainer.className = 'rule-search-container';
    searchContainer.innerHTML = '<input type="text" id="ruleSearch" placeholder="Поиск по правилам..." style="border-radius: 8px; border: 1px solid var(--input-border); background: var(--input-bg); color: var(--text-color);">';
    ruleOptions.appendChild(searchContainer);
    
    const categoriesContainer = document.createElement('div');
    categoriesContainer.id = 'ruleCategories';
    ruleOptions.appendChild(categoriesContainer);
    
    const searchResultsContainer = document.createElement('div');
    searchResultsContainer.id = 'ruleSearchResults';
    searchResultsContainer.className = 'rule-search-results';
    ruleOptions.appendChild(searchResultsContainer);
    
    ruleOptions.addEventListener('click', function(e) {
      const ruleOption = e.target.closest('.rule-option');
      if (ruleOption) {
        const ruleNumber = ruleOption.dataset.ruleNumber;
        const ruleText = ruleOption.dataset.ruleText;
        
        const selectedRule = document.getElementById('selectedRule');
        selectedRule.innerHTML = `
          <strong>Выбранное правило ${ruleNumber}:</strong><br>
          [QUOTE="${ruleNumber}"]${ruleText}[/QUOTE]
        `;
        // Добавлено сохранение данных в dataset
        selectedRule.dataset.ruleNumber = ruleNumber;
        selectedRule.dataset.ruleText = ruleText;
        
        slideDown(selectedRule, 300);
        slideUp(ruleOptions, 300);
      }
    });

    function renderCategories() {
      categoriesContainer.innerHTML = '';
      searchResultsContainer.style.display = 'none';
      categoriesContainer.style.display = 'block';
      
      for (const [categoryName, rules] of Object.entries(adminRules)) {
        const categoryElement = document.createElement('div');
        categoryElement.className = 'rule-category';
        categoryElement.innerHTML = `
          <div class="category-header">
            <span>${categoryName}</span>
            <span class="category-arrow">▶</span>
          </div>
          <div class="category-rules"></div>
        `;
        
        const header = categoryElement.querySelector('.category-header');
        const rulesContainer = categoryElement.querySelector('.category-rules');
        
        header.addEventListener('click', () => {
          const isOpen = rulesContainer.style.display === 'block';
          rulesContainer.style.display = isOpen ? 'none' : 'block';
          header.querySelector('.category-arrow').textContent = isOpen ? '▶' : '▼';
        });
        
        for (const [ruleNumber, ruleData] of Object.entries(rules)) {
          const ruleElement = document.createElement('div');
          ruleElement.className = 'rule-option';
          ruleElement.dataset.ruleNumber = ruleNumber;
          
          let fullRuleText = ruleData.text;
          if (ruleData.exceptions) {
            fullRuleText += `\n${ruleData.exceptions}`;
          }
          ruleElement.dataset.ruleText = fullRuleText;
          
          let displayText = ruleData.text;
          if (ruleData.exceptions) {
            displayText += " [исключение]";
          }
          
          ruleElement.innerHTML = `<strong>${ruleNumber}:</strong> ${displayText.substring(0, 80)}${displayText.length > 80 ? '...' : ''}`;
          rulesContainer.appendChild(ruleElement);
        }
        
        categoriesContainer.appendChild(categoryElement);
      }
    }
    
    document.getElementById('ruleSearch').addEventListener('input', function() {
      const searchText = this.value.toLowerCase().trim();
      
      if (searchText === '') {
        renderCategories();
        return;
      }
      
      categoriesContainer.style.display = 'none';
      searchResultsContainer.style.display = 'block';
      searchResultsContainer.innerHTML = '';
      
      let foundResults = false;
      
      for (const [categoryName, rules] of Object.entries(adminRules)) {
        for (const [ruleNumber, ruleData] of Object.entries(rules)) {
          const searchContent = `${ruleNumber} ${ruleData.text} ${ruleData.exceptions || ''} ${categoryName}`.toLowerCase();
          
          if (searchContent.includes(searchText)) {
            foundResults = true;
            const ruleElement = document.createElement('div');
            ruleElement.className = 'rule-option';
            ruleElement.dataset.ruleNumber = ruleNumber;
            
            let fullRuleText = ruleData.text;
            if (ruleData.exceptions) {
              fullRuleText += `\n${ruleData.exceptions}`;
            }
            ruleElement.dataset.ruleText = fullRuleText;
            
            let displayText = ruleData.text;
            if (ruleData.exceptions) {
              displayText += ` [исключение]`;
            }
            
            ruleElement.innerHTML = `
              <div><strong>${ruleNumber}</strong> (${categoryName})</div>
              <div>${displayText.substring(0, 100)}${displayText.length > 100 ? '...' : ''}</div>
            `;
            searchResultsContainer.appendChild(ruleElement);
          }
        }
      }
      
      if (!foundResults) {
        searchResultsContainer.innerHTML = '<div class="no-results">Ничего не найдено</div>';
      }
    });
    
    renderCategories();
    
    document.getElementById('ruleToggle').addEventListener('click', () => {
      const options = document.getElementById('ruleOptions');
      if (options.style.display === 'block') {
        slideUp(options, 300);
      } else {
        slideDown(options, 300);
        document.getElementById('ruleSearch').value = '';
        renderCategories();
      }
    });
    
     const closeForm = () => {
        fadeOut(proofForm, 300, () => {
            utils.removeElementById('proofForm');
            utils.removeStylesById('proofFormStyles');
            document.removeEventListener('keydown', handleKeyDown);
        });
    };
    
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        closeForm();
      } else if (e.ctrlKey && e.key === 'Enter') {
        document.getElementById('insertResponseBtn').click();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    
    document.getElementById('closeProofForm').addEventListener('click', async () => {
      closeForm();
      const adminMenu = await import(chrome.runtime.getURL('modules/adminMenu.js'));
      adminMenu.showAdminMenu();
    });
    
    document.getElementById('cancelProofForm').addEventListener('click', async () => {
      closeForm();
      const adminMenu = await import(chrome.runtime.getURL('modules/adminMenu.js'));
      adminMenu.showAdminMenu();
    });
    
    document.getElementById('insertResponseBtn').addEventListener('click', () => {
      const proofLink = document.getElementById('proofLink').value;
      const selectedRule = document.getElementById('selectedRule');
      const ruleNumber = selectedRule.dataset.ruleNumber;
      const ruleText = selectedRule.dataset.ruleText;
      const needTimestamps = document.getElementById('needTimestamps').checked;
      
      let response = `Доброго времени суток.
Я администратор, который выдал вам наказание.
Доказательства вашего нарушения → ${proofLink ? `[URL='${proofLink}']Доказательства[/URL]` : '[URL="Ссылка на доказательство"]Доказательства[/URL]'}`;
      
      if (needTimestamps) {
        const timestampRows = document.querySelectorAll('.timestamp-row');
        let hasTimestamps = false;
        let timestampsText = '';
        
        timestampRows.forEach(row => {
          const timeValue = row.querySelector('.timestamp-value').value.trim();
          const description = row.querySelector('.timestamp-description').value.trim();
          
          if (timeValue || description) {
            hasTimestamps = true;
            timestampsText += `${timeValue || '???'} - ${description || 'Нарушение'}\n`;
          }
        });
        
        if (hasTimestamps) {
          response += `\nТайм-коды:\n${timestampsText}`;
        }
      }
      
      if (ruleNumber) {
        response += `\n[QUOTE="${ruleNumber}"]${ruleText}[/QUOTE]`;
      }
      
      const needComment = document.getElementById('needComment').checked;
      if (needComment) {
        const comment = document.getElementById('adminComment').value.trim();
        if (comment) {
          response += `\n\n${comment}`;
        }
      }
      
      response += `\nОжидайте ответа от главной администрации.`;
      
      utils.insertIntoFroalaEditor(response);
      closeForm();
    });
    
    const proofHeader = document.getElementById('proofFormHeader');
    utils.createDraggable(proofForm, proofHeader);
    
    proofForm.addEventListener('click', (e) => e.stopPropagation());
    
    document.addEventListener('click', (e) => {
      if (!proofForm.contains(e.target) && e.target.id !== 'adminHelperBtn') {
        document.getElementById('ruleOptions').style.display = 'none';
      }
    });
  } catch (error) {
    console.error('Error showing proof form:', error);
  }
}