// Модуль анимаций
export function fadeIn(element, duration = 300, display = 'block') {
    element.style.opacity = '0';
    element.style.display = display;
    element.style.transition = `opacity ${duration}ms ease-in-out`;
    
    requestAnimationFrame(() => {
        element.style.opacity = '1';
    });
    
    setTimeout(() => {
        element.style.transition = '';
    }, duration);
}

export function fadeOut(element, duration = 300, callback) {
    element.style.opacity = '1';
    element.style.transition = `opacity ${duration}ms ease-in-out`;
    element.style.opacity = '0';
    
    setTimeout(() => {
        element.style.display = 'none';
        if (callback) callback();
        element.style.transition = '';
    }, duration);
}

export function slideToggle(element, duration = 300) {
    if (window.getComputedStyle(element).display === 'none') {
        slideDown(element, duration);
    } else {
        slideUp(element, duration);
    }
}

// Исправлено: экспорт функций
export function slideDown(element, duration) {
    element.style.display = 'block';
    const height = element.scrollHeight;
    element.style.overflow = 'hidden';
    element.style.height = '0';
    element.style.transition = `height ${duration}ms ease-in-out`;
    
    requestAnimationFrame(() => {
        element.style.height = `${height}px`;
    });
    
    setTimeout(() => {
        element.style.height = '';
        element.style.overflow = '';
        element.style.transition = '';
    }, duration);
}

export function slideUp(element, duration) {
    const height = element.scrollHeight;
    element.style.overflow = 'hidden';
    element.style.height = `${height}px`;
    element.style.transition = `height ${duration}ms ease-in-out`;
    
    requestAnimationFrame(() => {
        element.style.height = '0';
    });
    
    setTimeout(() => {
        element.style.display = 'none';
        element.style.height = '';
        element.style.overflow = '';
        element.style.transition = '';
    }, duration);
}

export function scrollSmooth(element, behavior = 'smooth', block = 'nearest') {
    element.scrollIntoView({ behavior, block });
}

// Анимация для цветовых элементов
export function colorTransition(element, property, duration = 300) {
    element.style.transition = `${property} ${duration}ms ease-in-out`;
}
// Добавляем функцию для плавного перемещения
export function smoothMove(element, property, value, duration = 300) {
  const start = parseFloat(getComputedStyle(element)[property]);
  const startTime = performance.now();
  
  function animate(time) {
    const elapsed = time - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const currentValue = start + (value - start) * progress;
    
    element.style[property] = `${currentValue}px`;
    
    if (progress < 1) {
      requestAnimationFrame(animate);
    }
  }
  
  requestAnimationFrame(animate);
}