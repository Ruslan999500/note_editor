let binds = [];
let outsideClickListener = null;
let handleKeyDown = null;

// НОВАЯ ФУНКЦИЯ ДЛЯ ФОРМАТИРОВАНИЯ ОТВЕТОВ
function formatResponse(text) {
    return text.replace(/\n/g, '[br][/br]')
               .replace(/\[br\]\[\/br\]\[br\]\[\/br\]/g, '[br][/br]')
               .replace(/\[QUOTE="(\d+)"\](.*?)\[\/QUOTE\]/gs, 
                        '[QUOTE="$1"]$2[/QUOTE][br][/br]');
}

export async function showBinderMenu() {
    try {
        const utils = await import(chrome.runtime.getURL('modules/utils.js'));
        
        // Удаляем старые обработчики
        if (outsideClickListener) {
            document.removeEventListener('click', outsideClickListener);
            outsideClickListener = null;
        }
        if (handleKeyDown) {
            document.removeEventListener('keydown', handleKeyDown);
            handleKeyDown = null;
        }
        
        // Удаляем другие открытые меню
        utils.removeElementById('adminHelperMenu');
        utils.removeElementById('binderMenu');
        utils.removeStylesById('binderMenuStyles');
        
        // Загружаем сохраненные бинды
        await loadBinds();
        
        const menu = document.createElement('div');
        menu.id = 'binderMenu';
        Object.assign(menu.style, {
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: 'var(--menu-bg)',
            border: '1px solid var(--menu-border)',
            borderRadius: '12px',
            padding: '20px',
            zIndex: '99999',
            color: 'var(--text-color)',
            boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 8px 24px rgba(0,0,0,0.5)',
            width: '500px',
            maxHeight: '80vh',
            overflowY: 'auto',
            cursor: 'default'
        });
        
        menu.innerHTML = `
            <div id="binderHeader" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; cursor: move; padding: 10px; margin: -20px -20px 15px -20px; background: var(--header-bg); border-radius: 12px 12px 0 0; border-bottom: 1px solid var(--menu-border);">
                <h3 style="margin: 0; padding-left: 10px;">Менеджер биндов</h3>
                <button id="closeBinderMenu" style="background: none; border: none; color: var(--text-color); cursor: pointer; font-size: 1.5rem; padding: 0 15px;">&times;</button>
            </div>
            <div style="display: flex; flex-direction: column; gap: 10px;">
                <button id="createNewBindBtn" class="binderMenuButton">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 5V19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <path d="M5 12H19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        <span>Добавить бинд</span>
                    </div>
                </button>
                
                <div id="bindsContainer" style="max-height: 300px; overflow-y: auto; padding: 10px; background: var(--section-bg); border-radius: 8px; border: 1px solid var(--menu-border);">
                    ${binds.length > 0 
                        ? binds.map(bind => `
                            <div class="bind-item" data-id="${bind.id}" style="padding: 10px; margin-bottom: 8px; background: var(--input-bg); border-radius: 8px; cursor: pointer; display: flex; justify-content: space-between; align-items: center;">
                                <span>${bind.name}</span>
                                <button class="deleteBindBtn" data-id="${bind.id}" style="background: #e74c3c; color: white; border: none; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;">×</button>
                            </div>
                        `).join('') 
                        : '<div style="text-align: center; padding: 20px; color: #a0aec0;">Нет сохраненных биндов</div>'}
                </div>
            </div>
        `;

        document.body.appendChild(menu);
        
        const style = document.createElement('style');
        style.id = 'binderMenuStyles';
        style.textContent = `
            .binderMenuButton {
                background-color: var(--button-bg);
                color: var(--button-text);
                border: none;
                border-radius: 8px;
                padding: 12px 15px;
                text-align: left;
                cursor: pointer;
                font-size: 16px;
                transition: all 0.2s ease;
                position: relative;
                border: 1px solid var(--button-border);
                box-shadow: 0 0 0 1px rgba(0,0,0,0.2);
            }
            .binderMenuButton:hover {
                background-color: var(--button-hover);
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.3);
            }
            .bind-item {
                transition: background-color 0.2s;
            }
            .bind-item:hover {
                background-color: var(--button-hover) !important;
            }
            .deleteBindBtn {
                transition: background-color 0.2s;
                opacity: 0.7;
            }
            .deleteBindBtn:hover {
                opacity: 1;
                background-color: #c0392b !important;
            }
            #bindsContainer::-webkit-scrollbar {
                width: 6px;
            }
            #bindsContainer::-webkit-scrollbar-track {
                background: var(--input-bg);
                border-radius: 8px;
            }
            #bindsContainer::-webkit-scrollbar-thumb {
                background: var(--button-bg);
                border-radius: 8px;
            }
            #bindsContainer::-webkit-scrollbar-thumb:hover {
                background: var(--button-hover);
            }
        `;
        document.head.appendChild(style);
        
        // Функция закрытия меню
        const closeMenu = () => {
            utils.removeElementById('binderMenu');
            utils.removeStylesById('binderMenuStyles');
            document.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('click', outsideClickListener);
            outsideClickListener = null;
            handleKeyDown = null;
        };
        
        // Обработчик клавиши ESC
        handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                closeMenu();
            }
        };
        document.addEventListener('keydown', handleKeyDown);
        
        // Обработчики событий
        document.getElementById('closeBinderMenu').addEventListener('click', closeMenu);
        
        document.getElementById('createNewBindBtn').addEventListener('click', () => {
            showBindEditor();
        });
        
        document.querySelectorAll('.bind-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.classList.contains('deleteBindBtn')) {
                    const bindId = item.dataset.id;
                    const bind = binds.find(b => b.id === bindId);
                    if (bind) {
                        // ИСПРАВЛЕНИЕ: Используем форматирование
                        const formattedContent = formatResponse(bind.content);
                        utils.insertIntoFroalaEditor(formattedContent);
                        closeMenu();
                    }
                }
            });
        });
        
        document.querySelectorAll('.deleteBindBtn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const bindId = btn.dataset.id;
                if (confirm('Вы уверены, что хотите удалить этот бинд?')) {
                    binds = binds.filter(b => b.id !== bindId);
                    await saveBinds();
                    // Обновляем меню вместо полного закрытия
                    closeMenu();
                    showBinderMenu();
                }
            });
        });
        
        // Drag and drop
        const header = document.getElementById('binderHeader');
        utils.createDraggable(menu, header);
        
        menu.addEventListener('click', (e) => e.stopPropagation());
        
        // Обработчик кликов вне меню
        outsideClickListener = (e) => {
            if (!menu.contains(e.target) && e.target.id !== 'binderHelperBtn') {
                closeMenu();
            }
        };
        document.addEventListener('click', outsideClickListener);
        
    } catch (error) {
        console.error('Error showing binder menu:', error);
        alert('Произошла ошибка при открытии менеджера биндов');
    }
}

async function showBindEditor(bindToEdit = null) {
    try {
        const utils = await import(chrome.runtime.getURL('modules/utils.js'));
        
        utils.removeElementById('binderMenu');
        utils.removeElementById('bindEditor');
        utils.removeStylesById('bindEditorStyles');
        
        const editor = document.createElement('div');
        editor.id = 'bindEditor';
        Object.assign(editor.style, {
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: 'var(--menu-bg)',
            border: '1px solid var(--menu-border)',
            borderRadius: '12px',
            padding: '20px',
            zIndex: '99999',
            color: 'var(--text-color)',
            boxShadow: '0 0 0 1px rgba(0,0,0,0.3), 0 8px 24px rgba(0,0,0,0.5)',
            width: '600px',
            maxHeight: '80vh',
            overflowY: 'auto',
            cursor: 'default'
        });
        
        const isEditMode = bindToEdit !== null;
        
        editor.innerHTML = `
            <div id="bindEditorHeader" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; cursor: move; padding: 10px; margin: -20px -20px 15px -20px; background: var(--header-bg); border-radius: 12px 12px 0 0; border-bottom: 1px solid var(--menu-border);">
                <h3 style="margin: 0; padding-left: 10px;">${isEditMode ? 'Редактирование бинда' : 'Добавление бинда'}</h3>
                <button id="closeBindEditor" style="background: none; border: none; color: var(--text-color); cursor: pointer; font-size: 1.5rem; padding: 0 15px;">&times;</button>
            </div>
            <div style="display: flex; flex-direction: column; gap: 15px;">
                <div>
                    <label for="bindName">Название бинда:</label>
                    <input type="text" id="bindName" value="${isEditMode ? bindToEdit.name : ''}" placeholder="Введите название" style="width: 100%; padding: 10px; margin-top: 5px; background: var(--input-bg); border: 1px solid var(--input-border); color: var(--text-color); border-radius: 8px; box-sizing: border-box;">
                </div>
                
                <div>
                    <label for="bindContent">Содержимое бинда:</label>
                    <textarea id="bindContent" placeholder="Введите текст бинда..." style="width: 100%; height: 200px; padding: 10px; margin-top: 5px; background: var(--input-bg); border: 1px solid var(--input-border); color: var(--text-color); border-radius: 8px; box-sizing: border-box; resize: vertical;">${isEditMode ? bindToEdit.content : ''}</textarea>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 10px;">
                    <button id="saveBindBtn" style="flex: 1; padding: 10px; background: var(--button-bg); color: var(--button-text); border: none; border-radius: 8px; cursor: pointer; border: 1px solid var(--button-border);">
                        ${isEditMode ? 'Сохранить изменения' : 'Сохранить'}
                    </button>
                    <button id="cancelBindEditorBtn" style="flex: 1; padding: 10px; background: var(--button-bg); color: var(--button-text); border: none; border-radius: 8px; cursor: pointer; border: 1px solid var(--button-border);">
                        Отмена
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(editor);
        
        const style = document.createElement('style');
        style.id = 'bindEditorStyles';
        style.textContent = `
            #bindEditor input, #bindEditor textarea {
                transition: border-color 0.2s;
            }
            #bindEditor input:focus, #bindEditor textarea:focus {
                outline: none;
                border-color: var(--button-hover);
            }
            #bindEditor button {
                transition: background-color 0.2s;
            }
            #bindEditor button:hover {
                background-color: var(--button-hover) !important;
            }
        `;
        document.head.appendChild(style);
        
        // Функция закрытия редактора
        const closeEditor = () => {
            utils.removeElementById('bindEditor');
            utils.removeStylesById('bindEditorStyles');
            document.removeEventListener('keydown', handleKeyDown);
            document.removeEventListener('click', outsideClickListener);
        };
        
        // Обработчик клавиши ESC
        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                closeEditor();
            }
        };
        document.addEventListener('keydown', handleKeyDown);
        
        // Обработчик кликов вне редактора
        const outsideClickListener = (e) => {
            if (!editor.contains(e.target)) {
                closeEditor();
            }
        };
        document.addEventListener('click', outsideClickListener);
        
        // Обработчики событий
        document.getElementById('closeBindEditor').addEventListener('click', closeEditor);
        
        document.getElementById('cancelBindEditorBtn').addEventListener('click', closeEditor);
        
        document.getElementById('saveBindBtn').addEventListener('click', async () => {
            const name = document.getElementById('bindName').value.trim();
            const content = document.getElementById('bindContent').value.trim();
            
            if (!name) {
                alert('Пожалуйста, введите название бинда');
                return;
            }
            
            if (!content) {
                alert('Пожалуйста, введите содержимое бинда');
                return;
            }
            
            if (isEditMode) {
                // Обновление существующего бинда
                binds = binds.map(b => 
                    b.id === bindToEdit.id 
                        ? {...b, name, content} 
                        : b
                );
            } else {
                // Создание нового бинда
                const newBind = {
                    id: Date.now().toString(),
                    name,
                    content
                };
                binds.push(newBind);
            }
            
            await saveBinds();
            closeEditor();
            showBinderMenu();
        });
        
        // Drag and drop
        const header = document.getElementById('bindEditorHeader');
        utils.createDraggable(editor, header);
        
        editor.addEventListener('click', (e) => e.stopPropagation());
        
    } catch (error) {
        console.error('Error showing bind editor:', error);
    }
}

async function loadBinds() {
    return new Promise(resolve => {
        chrome.storage.local.get(['binds'], (result) => {
            if (result.binds && Array.isArray(result.binds)) {
                binds = result.binds;
            } else {
                binds = [];
            }
            resolve();
        });
    });
}

async function saveBinds() {
    return new Promise(resolve => {
        chrome.storage.local.set({ binds }, () => {
            console.log('Binds saved');
            resolve();
        });
    });
}