function initialize() {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
}

async function initApp() {
  try {
    const { initExtension } = await import(chrome.runtime.getURL('modules/adminMenu.js'));
    await initExtension();
  } catch (error) {
    console.error('Error initializing extension:', error);
  }
}

initialize();